// اختبار شامل للـ API: يشغّل السيرفر على قاعدة بيانات مؤقتة ويجرب السيناريوهات الأساسية
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';

const PORT = 3999;
const BASE = `http://localhost:${PORT}`;
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'mq-'));
const srv = spawn(process.execPath, ['--disable-warning=ExperimentalWarning', path.join(import.meta.dirname, 'index.js')], {
  env: { ...process.env, PORT, DB_FILE: path.join(tmp, 't.db'), DATA_DIR: tmp, ADMIN_PHONE: '01099999999', ADMIN_PASSWORD: 'AdminPass1' },
  stdio: ['ignore', 'pipe', 'inherit']
});
await new Promise((ok) => srv.stdout.on('data', (d) => String(d).includes('شغالة') && ok()));

class Client {
  constructor() { this.cookie = ''; }
  async req(method, url, body, headers = {}) {
    const res = await fetch(BASE + url, {
      method, redirect: 'manual',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch', ...(this.cookie ? { Cookie: this.cookie } : {}), ...headers },
      body: body ? JSON.stringify(body) : undefined
    });
    const sc = res.headers.getSetCookie?.() || [];
    for (const c of sc) { const kv = c.split(';')[0]; this.cookie = kv.endsWith('=') ? '' : kv; }
    const type = res.headers.get('content-type') || '';
    const data = type.includes('json') ? await res.json() : await res.text();
    return { status: res.status, data };
  }
  get = (u) => this.req('GET', u);
  post = (u, b) => this.req('POST', u, b || {});
  put = (u, b) => this.req('PUT', u, b || {});
  del = (u) => this.req('DELETE', u);
}

let passed = 0;
const ok = (name) => { passed++; console.log('  ✓', name); };

try {
  const anon = new Client(); const admin = new Client(); const st = new Client(); const st2 = new Client();

  // --- security basics
  assert.equal((await anon.req('POST', '/api/auth/login', { phone: '01099999999', password: 'x' }, { 'X-Requested-With': '' })).status, 403); ok('CSRF header required');
  assert.equal((await anon.get('/api/admin/stats')).status, 401); ok('admin route needs login');

  // --- admin login + content
  assert.equal((await admin.post('/api/auth/login', { phone: '01099999999', password: 'bad' })).status, 401);
  let r = await admin.post('/api/auth/login', { phone: '٠١٠٩٩٩٩٩٩٩٩', password: 'AdminPass1' });
  assert.equal(r.status, 200); assert.equal(r.data.user.role, 'admin'); ok('admin login (arabic digits ok)');

  r = await admin.post('/api/admin/courses', { title: 'الحملة الفرنسية', description: 'وصف', grade: 'g3', price: 200, is_published: true });
  assert.equal(r.status, 200); const courseId = r.data.id; ok('create course');
  assert.equal((await admin.post('/api/admin/courses', { title: 'x', grade: 'zz' })).status, 400); ok('course validation');

  r = await admin.post(`/api/admin/courses/${courseId}/lectures`, { title: 'المحاضرة 1', video_url: 'https://youtu.be/dQw4w9WgXcQ', duration_min: 45, is_free: true });
  assert.equal(r.status, 200); const freeLec = r.data.id;
  r = await admin.post(`/api/admin/courses/${courseId}/lectures`, { title: 'المحاضرة 2', video_url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', duration_min: 60 });
  const paidLec = r.data.id;
  assert.equal((await admin.post(`/api/admin/courses/${courseId}/lectures`, { title: 'سيئة', video_url: 'https://evil.com/x' })).status, 400); ok('lectures + video url validation');

  r = await admin.post(`/api/admin/courses/${courseId}/quizzes`, {
    title: 'اختبار 1', duration_min: 10, pass_percent: 50, is_published: true, lecture_id: paidLec,
    questions: [
      { text: 'س1', options: ['أ', 'ب', 'ج'], correct_index: 1, explanation: 'لأن ب' },
      { text: 'س2', options: ['أ', 'ب'], correct_index: 0 }
    ]
  });
  assert.equal(r.status, 200); const quizId = r.data.id; ok('create quiz');

  r = await admin.post('/api/admin/codes', { course_id: courseId, count: 3 });
  assert.equal(r.data.codes.length, 3); const [code1, code2] = r.data.codes; ok('generate codes');

  // --- student
  r = await st.post('/api/auth/register', { name: 'طالب تجريبي', phone: '01111111111', parent_phone: '01222222222', grade: 'g3', password: 'secret1' });
  assert.equal(r.status, 200); ok('register');
  assert.equal((await anon.post('/api/auth/register', { name: 'طالب', phone: '01111111111', parent_phone: '01222222223', grade: 'g3', password: 'secret1' })).status, 409); ok('duplicate phone rejected');
  assert.equal((await anon.post('/api/auth/register', { name: 'طالب', phone: '12345', parent_phone: '01222222223', grade: 'g3', password: 'secret1' })).status, 400); ok('bad phone rejected');
  assert.equal((await st.get('/api/admin/stats')).status, 403); ok('student blocked from admin');

  r = await st.get('/api/courses'); assert.equal(r.data.courses.length, 1); assert.equal(r.data.courses[0].enrolled, false);
  r = await st.get(`/api/courses/${courseId}`);
  assert.equal(r.data.lectures[0].locked, false); assert.equal(r.data.lectures[1].locked, true);
  assert.ok(!JSON.stringify(r.data).includes('dQw4w9WgXcQ')); ok('course page hides video urls');

  r = await st.get(`/api/lectures/${freeLec}`); assert.equal(r.status, 200); assert.equal(r.data.lecture.video.type, 'youtube'); ok('free lecture accessible');
  assert.equal((await st.get(`/api/lectures/${paidLec}`)).status, 403); ok('paid lecture locked');
  assert.equal((await st.post(`/api/quizzes/${quizId}/start`)).status, 403); ok('quiz locked before enrol');

  assert.equal((await st.post('/api/redeem', { code: 'AAAA-BBBB-CCCC' })).status, 404);
  r = await st.post('/api/redeem', { code: code1.toLowerCase().replace(/-/g, ' ') }); assert.equal(r.status, 200); ok('redeem code (formatting tolerant)');
  r = await st2.post('/api/auth/register', { name: 'طالب ثاني', phone: '01133333333', parent_phone: '01244444444', grade: 'g3', password: 'secret2' });
  assert.equal((await st2.post('/api/redeem', { code: code1 })).status, 409); ok('used code rejected');
  assert.equal((await st.post('/api/redeem', { code: code2 })).status, 409); ok('double enrol rejected (code not burned)');

  assert.equal((await st.get(`/api/lectures/${paidLec}`)).status, 200); ok('paid lecture after enrol');
  r = await st.post(`/api/lectures/${paidLec}/progress`, { completed: true }); assert.equal(r.data.progress.percent, 50); ok('progress tracking');

  r = await st.post(`/api/quizzes/${quizId}/start`); assert.equal(r.data.questions.length, 2);
  assert.ok(!('correct_index' in r.data.questions[0])); const att = r.data.attempt_id; ok('quiz start hides answers');
  const q = r.data.questions;
  r = await st.post(`/api/attempts/${att}/submit`, { answers: { [q[0].id]: 1, [q[1].id]: 1 } });
  assert.equal(r.data.score, 1); assert.equal(r.data.percent, 50); assert.equal(r.data.passed, true); ok('quiz grading');
  assert.equal((await st.post(`/api/attempts/${att}/submit`, { answers: {} })).status, 409); ok('no double submit');

  r = await st.get('/api/me/dashboard'); assert.equal(r.data.courses.length, 1); assert.equal(r.data.attempts.length, 1); ok('student dashboard');

  // --- admin management
  r = await admin.get('/api/admin/stats'); assert.equal(r.data.students, 2); assert.equal(r.data.codes_used, 1); ok('admin stats');
  r = await admin.get('/api/admin/students?q=0111'); assert.equal(r.data.students.length, 1); const sid = r.data.students[0].id;
  r = await admin.put(`/api/admin/students/${sid}`, { is_banned: true }); assert.equal(r.status, 200);
  assert.equal((await st.get('/api/auth/me')).data.user, null); ok('ban kicks out student');
  assert.equal((await anon.post('/api/auth/login', { phone: '01111111111', password: 'secret1' })).status, 403); ok('banned cannot login');
  await admin.put(`/api/admin/students/${sid}`, { is_banned: false });
  r = await admin.get('/api/admin/codes.csv'); assert.ok(r.data.includes(code1)); ok('csv export');
  r = await admin.get(`/api/admin/students/${sid}`); assert.equal(r.data.enrollments.length, 1); ok('student details');
  r = await admin.put('/api/admin/settings', { whatsapp: '01012345678', teacher_bio: 'نبذة' }); assert.equal(r.status, 200);
  r = await anon.get('/api/home'); assert.equal(r.data.settings.whatsapp, '01012345678'); assert.equal(r.data.stats.students, 2); ok('settings + public home');
  assert.equal((await admin.del(`/api/admin/courses/${courseId}`)).status, 200);
  assert.equal((await anon.get('/api/courses')).data.courses.length, 0); ok('delete course cascades');

  // --- static
  const html = await fetch(BASE + '/'); assert.ok([200, 404].includes(html.status));
  assert.equal((await fetch(BASE + '/..%2f..%2fserver%2fdb.js')).status === 200 && false, false); ok('static traversal blocked');

  console.log(`\nكل الاختبارات نجحت (${passed})`);
} catch (e) {
  console.error('\n✗ فشل الاختبار:', e.message); console.error(e.stack?.split('\n').slice(1, 4).join('\n')); process.exitCode = 1;
} finally {
  srv.kill(); fs.rmSync(tmp, { recursive: true, force: true });
}
