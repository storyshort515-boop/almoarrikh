// بيانات تجريبية اختيارية لتجربة المنصة (مش لازمة للتشغيل الحقيقي).
// الاستخدام: npm run seed:demo
import { db, tx } from './db.js';
import { hashPassword } from './lib.js';
import crypto from 'node:crypto';

if (db.prepare('SELECT 1 FROM courses LIMIT 1').get()) {
  console.log('فيه كورسات موجودة بالفعل، تم تخطي البيانات التجريبية.');
  process.exit(0);
}

const course = (title, description, grade, price) =>
  db.prepare('INSERT INTO courses(title,description,grade,price,is_published,sort_order) VALUES(?,?,?,?,1,1)').run(title, description, grade, price).lastInsertRowid;
const lecture = (cid, title, min, free, order) =>
  db.prepare('INSERT INTO lectures(course_id,title,description,duration_min,is_free,sort_order) VALUES(?,?,?,?,?,?)').run(cid, title, 'محاضرة تجريبية: استبدلها برابط الفيديو الحقيقي من لوحة التحكم.', min, free, order).lastInsertRowid;

tx(() => {
  const c3 = course('الحملة الفرنسية ومحمد علي (تجريبي)', 'كورس تجريبي يوضح شكل الكورسات على المنصة. عدّله أو احذفه من لوحة التحكم.', 'g3', 250);
  const l1 = lecture(c3, 'الحملة الفرنسية: الأسباب والنتائج', 55, 1, 1);
  lecture(c3, 'محمد علي وبناء الدولة الحديثة', 70, 0, 2);
  lecture(c3, 'الاحتلال البريطاني وثورة عرابي', 65, 0, 3);
  const c1 = course('مصر القديمة (تجريبي)', 'كورس تجريبي للصف الأول الثانوي.', 'g1', 150);
  lecture(c1, 'نشأة الحضارة المصرية', 50, 1, 1);
  lecture(c1, 'الدولة القديمة والوسطى والحديثة', 60, 0, 2);
  const c2 = course('مصر في العصر الإسلامي (تجريبي)', 'كورس تجريبي للصف الثاني الثانوي.', 'g2', 200);
  lecture(c2, 'الفتح الإسلامي لمصر', 55, 1, 1);

  const qz = db.prepare('INSERT INTO quizzes(course_id,lecture_id,title,duration_min,pass_percent,is_published) VALUES(?,?,?,?,?,1)').run(c3, l1, 'اختبار الحملة الفرنسية (تجريبي)', 10, 50).lastInsertRowid;
  const q = db.prepare('INSERT INTO questions(quiz_id,text,options,correct_index,explanation,sort_order) VALUES(?,?,?,?,?,?)');
  q.run(qz, 'من قاد الحملة الفرنسية على مصر؟', JSON.stringify(['محمد علي', 'نابليون بونابرت', 'كليبر', 'مينو']), 1, 'قادها نابليون بونابرت ووصلت الإسكندرية سنة 1798.', 1);
  q.run(qz, 'في أي سنة بدأت الحملة الفرنسية على مصر؟', JSON.stringify(['1789', '1798', '1805', '1882']), 1, '', 2);
  q.run(qz, 'في أي سنة تولى محمد علي حكم مصر؟', JSON.stringify(['1798', '1801', '1805', '1848']), 2, 'اختاره العلماء والأعيان واليًا على مصر سنة 1805.', 3);

  const ins = db.prepare('INSERT INTO codes(code,course_id,batch) VALUES(?,?,?)');
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const mk = () => { const b = crypto.randomBytes(12); let s = ''; for (let i = 0; i < 12; i++) s += A[b[i] % 32]; return s.match(/.{4}/g).join('-'); };
  const codes = [mk(), mk()]; codes.forEach((c) => ins.run(c, c3, 'demo'));
  console.log('أكواد تجريبية لكورس الحملة الفرنسية:', codes.join('  '));
});

if (!db.prepare("SELECT 1 FROM users WHERE phone='01100000000'").get()) {
  db.prepare("INSERT INTO users(name,phone,parent_phone,grade,password_hash) VALUES(?,?,?,?,?)")
    .run('طالب تجريبي', '01100000000', '01200000000', 'g3', await hashPassword('demo1234'));
  console.log('طالب تجريبي: 01100000000 / demo1234');
}
console.log('تم إنشاء البيانات التجريبية.');
