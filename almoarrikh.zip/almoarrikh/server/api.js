import crypto from 'node:crypto';
import { db, tx, DEFAULT_SETTINGS } from './db.js';
import * as L from './lib.js';

const { E, str, int, bool, httpUrl } = L;

export const GRADES = [
  { id: 'g1', name: 'الصف الأول الثانوي', short: 'أولى ثانوي' },
  { id: 'g2', name: 'الصف الثاني الثانوي (البكالوريا)', short: 'تانية بكالوريا' },
  { id: 'g3', name: 'الصف الثالث الثانوي', short: 'تالتة ثانوي' }
];
const gradeIds = GRADES.map((g) => g.id);
const COOKIE = 'mq_sid';
const SESSION_DAYS = 30;

/* ------------------------------------------------------------------ */
/* router                                                              */
/* ------------------------------------------------------------------ */
const routes = [];
function R(method, path, guard, handler) {
  const keys = [];
  const re = new RegExp('^' + path.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
  routes.push({ method, re, keys, guard, handler });
}

export async function handleApi(req, res, url) {
  const method = req.method;
  let match = null; let params = {}; let pathMatched = false;
  for (const r of routes) {
    const m = r.re.exec(url.pathname);
    if (!m) continue;
    pathMatched = true;
    if (r.method !== method) continue;
    match = r; r.keys.forEach((k, i) => (params[k] = decodeURIComponent(m[i + 1])));
    break;
  }
  if (!match) return send(res, pathMatched ? 405 : 404, { error: pathMatched ? 'طريقة الطلب غير مسموحة' : 'غير موجود' });

  const mutating = method !== 'GET' && method !== 'HEAD';
  if (mutating) {
    const origin = req.headers.origin;
    if (origin) {
      try { if (new URL(origin).host !== req.headers.host) throw E(403, 'طلب مرفوض'); }
      catch (e) { if (e instanceof L.HttpError) throw e; throw E(403, 'طلب مرفوض'); }
    }
    if (req.headers['x-requested-with'] !== 'fetch') throw E(403, 'طلب مرفوض');
  }

  const user = getUser(req);
  if (match.guard !== 'public' && !user) throw E(401, 'سجّل دخولك الأول');
  if (match.guard === 'admin' && user.role !== 'admin') throw E(403, 'غير مصرح لك');

  const ctx = {
    req, res, params, user,
    query: Object.fromEntries(url.searchParams),
    body: mutating ? await L.readJson(req) : {},
    ip: L.clientIp(req),
    cookies: []
  };
  const out = await match.handler(ctx);
  if (ctx.cookies.length) res.setHeader('Set-Cookie', ctx.cookies);
  if (out && out.raw !== undefined) {
    res.writeHead(200, {
      'Content-Type': out.type || 'text/plain; charset=utf-8',
      ...(out.filename ? { 'Content-Disposition': `attachment; filename="${out.filename}"` } : {}),
      'Cache-Control': 'no-store'
    });
    return res.end(out.raw);
  }
  return send(res, 200, out ?? { ok: true });
}

export function send(res, status, data) {
  if (res.headersSent) return;
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(data));
}

/* ------------------------------------------------------------------ */
/* sessions                                                            */
/* ------------------------------------------------------------------ */
function cookieStr(req, value, maxAge) {
  const secure = process.env.COOKIE_SECURE === '1' || req.headers['x-forwarded-proto'] === 'https';
  return `${COOKIE}=${encodeURIComponent(value)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${secure ? '; Secure' : ''}`;
}
function getUser(req) {
  const tok = L.parseCookies(req)[COOKIE];
  if (!tok) return null;
  const row = db.prepare(
    `SELECT u.id,u.name,u.phone,u.parent_phone,u.grade,u.role,u.is_banned
       FROM sessions s JOIN users u ON u.id=s.user_id
      WHERE s.token_hash=? AND s.expires_at>unixepoch()`
  ).get(L.sha(tok));
  if (!row || row.is_banned) return null;
  return row;
}
function startSession(ctx, user) {
  const token = L.newToken();
  db.prepare('INSERT INTO sessions(token_hash,user_id,user_agent,expires_at) VALUES(?,?,?,unixepoch()+?)')
    .run(L.sha(token), user.id, String(ctx.req.headers['user-agent'] || '').slice(0, 200), SESSION_DAYS * 86400);
  if (user.role !== 'admin') {
    const max = Math.max(1, Number(process.env.MAX_DEVICES || 2));
    db.prepare(`DELETE FROM sessions WHERE user_id=? AND token_hash NOT IN
      (SELECT token_hash FROM sessions WHERE user_id=? ORDER BY created_at DESC, rowid DESC LIMIT ?)`).run(user.id, user.id, max);
  }
  db.prepare('UPDATE users SET last_login=unixepoch() WHERE id=?').run(user.id);
  ctx.cookies.push(cookieStr(ctx.req, token, SESSION_DAYS * 86400));
}
const publicUser = (u) => ({ id: u.id, name: u.name, phone: u.phone, parent_phone: u.parent_phone, grade: u.grade, role: u.role });

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */
const getSettings = () => Object.fromEntries(db.prepare('SELECT key,value FROM settings').all().map((r) => [r.key, r.value]));
function hasAccess(user, courseId) {
  if (!user) return false;
  if (user.role === 'admin') return true;
  return !!db.prepare('SELECT 1 FROM enrollments WHERE user_id=? AND course_id=?').get(user.id, courseId);
}
function courseProgress(userId, courseId) {
  const total = db.prepare('SELECT COUNT(*) n FROM lectures WHERE course_id=? AND is_published=1').get(courseId).n;
  const done = db.prepare(`SELECT COUNT(*) n FROM progress p JOIN lectures l ON l.id=p.lecture_id
     WHERE p.user_id=? AND l.course_id=? AND l.is_published=1 AND p.completed=1`).get(userId, courseId).n;
  return { total, done, percent: total ? Math.round((done / total) * 100) : 0 };
}
const COURSE_SELECT = `SELECT c.*,
  (SELECT COUNT(*) FROM lectures l WHERE l.course_id=c.id AND l.is_published=1) AS lectures_count,
  (SELECT COALESCE(SUM(duration_min),0) FROM lectures l WHERE l.course_id=c.id AND l.is_published=1) AS total_minutes,
  (SELECT COUNT(*) FROM enrollments e WHERE e.course_id=c.id) AS students_count
  FROM courses c`;
function nextOrder(table, col, id) {
  return db.prepare(`SELECT COALESCE(MAX(sort_order),0)+1 n FROM ${table} WHERE ${col}=?`).get(id).n;
}
const ALPH = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function genCode() {
  const b = crypto.randomBytes(12); let s = '';
  for (let i = 0; i < 12; i++) s += ALPH[b[i] % ALPH.length];
  return s.match(/.{4}/g).join('-');
}
const csvCell = (v) => { v = String(v ?? ''); return /[",\n]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v; };
const toCsv = (rows) => '﻿' + rows.map((r) => r.map(csvCell).join(',')).join('\r\n');

/* ------------------------------------------------------------------ */
/* auth                                                                */
/* ------------------------------------------------------------------ */
R('POST', '/api/auth/register', 'public', async (c) => {
  L.rateLimit('reg:' + c.ip, 10, 3600_000);
  const name = str(c.body.name, { min: 3, max: 60, label: 'الاسم' });
  const phone = L.normPhone(c.body.phone);
  const parent = L.normPhone(c.body.parent_phone);
  if (!L.isEgPhone(phone)) throw E(400, 'رقم الموبايل غير صحيح');
  if (!L.isEgPhone(parent)) throw E(400, 'رقم موبايل ولي الأمر غير صحيح');
  if (parent === phone) throw E(400, 'رقم ولي الأمر لازم يكون مختلف عن رقمك');
  if (!gradeIds.includes(c.body.grade)) throw E(400, 'اختر الصف الدراسي');
  const password = String(c.body.password ?? '');
  if (password.length < 6 || password.length > 72) throw E(400, 'كلمة المرور لازم تكون من 6 إلى 72 حرف');
  if (db.prepare('SELECT 1 FROM users WHERE phone=?').get(phone)) throw E(409, 'الرقم ده مسجل قبل كده، جرّب تسجيل الدخول');
  const hash = await L.hashPassword(password);
  const r = db.prepare('INSERT INTO users(name,phone,parent_phone,grade,password_hash) VALUES(?,?,?,?,?)').run(name, phone, parent, c.body.grade, hash);
  const user = db.prepare('SELECT * FROM users WHERE id=?').get(r.lastInsertRowid);
  startSession(c, user);
  return { user: publicUser(user) };
});

R('POST', '/api/auth/login', 'public', async (c) => {
  const phone = L.normPhone(c.body.phone);
  L.rateLimit('login:' + c.ip, 30, 600_000);
  L.rateLimit('loginp:' + phone, 8, 600_000);
  const password = String(c.body.password ?? '');
  const row = db.prepare('SELECT * FROM users WHERE phone=?').get(phone);
  const ok = row ? await L.verifyPassword(password, row.password_hash) : (await L.verifyPassword(password, 's1$00$00'), false);
  if (!ok) throw E(401, 'رقم الموبايل أو كلمة المرور غير صحيحة');
  if (row.is_banned) throw E(403, 'الحساب موقوف، تواصل مع الدعم');
  startSession(c, row);
  return { user: publicUser(row) };
});

R('POST', '/api/auth/logout', 'public', (c) => {
  const tok = L.parseCookies(c.req)[COOKIE];
  if (tok) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(L.sha(tok));
  c.cookies.push(cookieStr(c.req, '', 0));
  return { ok: true };
});

R('GET', '/api/auth/me', 'public', (c) => ({ user: c.user ? publicUser(c.user) : null }));

R('POST', '/api/auth/change-password', 'user', async (c) => {
  const row = db.prepare('SELECT * FROM users WHERE id=?').get(c.user.id);
  if (!(await L.verifyPassword(String(c.body.current ?? ''), row.password_hash))) throw E(400, 'كلمة المرور الحالية غير صحيحة');
  const np = String(c.body.next ?? '');
  if (np.length < 6 || np.length > 72) throw E(400, 'كلمة المرور الجديدة لازم تكون من 6 إلى 72 حرف');
  db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(await L.hashPassword(np), c.user.id);
  const tok = L.parseCookies(c.req)[COOKIE];
  db.prepare('DELETE FROM sessions WHERE user_id=? AND token_hash<>?').run(c.user.id, L.sha(tok));
  return { ok: true };
});

/* ------------------------------------------------------------------ */
/* public / student                                                    */
/* ------------------------------------------------------------------ */
R('GET', '/api/health', 'public', () => ({ ok: true }));

R('GET', '/api/home', 'public', (c) => {
  const s = getSettings();
  const stats = {
    students: db.prepare("SELECT COUNT(*) n FROM users WHERE role='student'").get().n,
    courses: db.prepare('SELECT COUNT(*) n FROM courses WHERE is_published=1').get().n,
    lectures: db.prepare('SELECT COUNT(*) n FROM lectures l JOIN courses c ON c.id=l.course_id WHERE l.is_published=1 AND c.is_published=1').get().n
  };
  const courses = db.prepare(`${COURSE_SELECT} WHERE c.is_published=1 ORDER BY c.created_at DESC, c.id DESC LIMIT 6`).all();
  const ann = db.prepare('SELECT id,title,body,grade,created_at FROM announcements WHERE is_active=1 ORDER BY created_at DESC LIMIT 5').all();
  return { settings: s, grades: GRADES, stats, courses: markEnrolled(c.user, courses), announcements: ann };
});

function markEnrolled(user, courses) {
  if (!user) return courses.map((x) => ({ ...x, enrolled: false }));
  const set = new Set(db.prepare('SELECT course_id FROM enrollments WHERE user_id=?').all(user.id).map((r) => r.course_id));
  return courses.map((x) => ({ ...x, enrolled: user.role === 'admin' || set.has(x.id) }));
}

R('GET', '/api/courses', 'public', (c) => {
  const g = c.query.grade;
  const rows = g && gradeIds.includes(g)
    ? db.prepare(`${COURSE_SELECT} WHERE c.is_published=1 AND c.grade=? ORDER BY c.sort_order, c.id`).all(g)
    : db.prepare(`${COURSE_SELECT} WHERE c.is_published=1 ORDER BY c.grade, c.sort_order, c.id`).all();
  return { courses: markEnrolled(c.user, rows), grades: GRADES };
});

R('GET', '/api/courses/:id', 'public', (c) => {
  const course = db.prepare(`${COURSE_SELECT} WHERE c.id=?`).get(c.params.id);
  if (!course || (!course.is_published && c.user?.role !== 'admin')) throw E(404, 'الكورس غير موجود');
  const access = hasAccess(c.user, course.id);
  const done = new Set(c.user ? db.prepare('SELECT lecture_id FROM progress WHERE user_id=? AND completed=1').all(c.user.id).map((r) => r.lecture_id) : []);
  const lectures = db.prepare('SELECT id,title,description,duration_min,is_free,sort_order FROM lectures WHERE course_id=? AND is_published=1 ORDER BY sort_order,id')
    .all(course.id).map((l) => ({ ...l, locked: !(access || l.is_free), completed: done.has(l.id) }));
  const quizzes = db.prepare(`SELECT q.id,q.title,q.duration_min,q.pass_percent,q.lecture_id,
      (SELECT COUNT(*) FROM questions WHERE quiz_id=q.id) AS questions_count
      FROM quizzes q WHERE q.course_id=? AND q.is_published=1 ORDER BY q.id`).all(course.id);
  return {
    course: { ...course, enrolled: access },
    lectures, quizzes: access ? quizzes : quizzes.map((q) => ({ ...q, locked: true })),
    progress: c.user && access ? courseProgress(c.user.id, course.id) : null,
    settings: { whatsapp: getSettings().whatsapp }
  };
});

R('GET', '/api/lectures/:id', 'user', (c) => {
  const lec = db.prepare('SELECT * FROM lectures WHERE id=?').get(c.params.id);
  if (!lec || (!lec.is_published && c.user.role !== 'admin')) throw E(404, 'المحاضرة غير موجودة');
  const course = db.prepare('SELECT id,title,grade,is_published FROM courses WHERE id=?').get(lec.course_id);
  if (!course.is_published && c.user.role !== 'admin') throw E(404, 'المحاضرة غير موجودة');
  if (!(lec.is_free || hasAccess(c.user, lec.course_id))) throw E(403, 'لازم تشترك في الكورس الأول');
  const list = db.prepare('SELECT id,title,duration_min,is_free FROM lectures WHERE course_id=? AND is_published=1 ORDER BY sort_order,id').all(lec.course_id);
  const access = hasAccess(c.user, lec.course_id);
  const done = new Set(db.prepare('SELECT lecture_id FROM progress WHERE user_id=? AND completed=1').all(c.user.id).map((r) => r.lecture_id));
  const idx = list.findIndex((x) => x.id === lec.id);
  const quizzes = db.prepare(`SELECT id,title,duration_min,pass_percent,
      (SELECT COUNT(*) FROM questions WHERE quiz_id=quizzes.id) AS questions_count
      FROM quizzes WHERE lecture_id=? AND is_published=1`).all(lec.id);
  return {
    lecture: {
      id: lec.id, title: lec.title, description: lec.description, duration_min: lec.duration_min,
      video: L.parseVideo(lec.video_url), pdf_url: lec.pdf_url, completed: done.has(lec.id)
    },
    course,
    watermark: `${c.user.name} - ${c.user.phone}`,
    playlist: list.map((x) => ({ ...x, locked: !(access || x.is_free), completed: done.has(x.id) })),
    prev: idx > 0 ? list[idx - 1].id : null,
    next: idx >= 0 && idx < list.length - 1 ? list[idx + 1].id : null,
    quizzes
  };
});

R('POST', '/api/lectures/:id/progress', 'user', (c) => {
  const lec = db.prepare('SELECT id,course_id,is_free FROM lectures WHERE id=?').get(c.params.id);
  if (!lec || !(lec.is_free || hasAccess(c.user, lec.course_id))) throw E(403, 'غير مصرح');
  const completed = bool(c.body.completed);
  db.prepare(`INSERT INTO progress(user_id,lecture_id,completed,updated_at) VALUES(?,?,?,unixepoch())
     ON CONFLICT(user_id,lecture_id) DO UPDATE SET completed=excluded.completed, updated_at=unixepoch()`).run(c.user.id, lec.id, completed);
  return { ok: true, completed: !!completed, progress: courseProgress(c.user.id, lec.course_id) };
});

R('POST', '/api/redeem', 'user', (c) => {
  L.rateLimit('redeem:' + c.user.id, 10, 3600_000);
  const code = String(c.body.code ?? '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (code.length !== 12) throw E(400, 'الكود غير صحيح، اكتبه بالظبط زي ما هو مكتوب');
  const formatted = code.match(/.{4}/g).join('-');
  return tx(() => {
    const row = db.prepare('SELECT * FROM codes WHERE code=?').get(formatted);
    if (!row) throw E(404, 'الكود غير صحيح');
    if (row.used_by) throw E(409, 'الكود ده اتستخدم قبل كده');
    if (db.prepare('SELECT 1 FROM enrollments WHERE user_id=? AND course_id=?').get(c.user.id, row.course_id)) throw E(409, 'أنت مشترك في الكورس ده بالفعل');
    db.prepare('UPDATE codes SET used_by=?, used_at=unixepoch() WHERE id=?').run(c.user.id, row.id);
    db.prepare("INSERT INTO enrollments(user_id,course_id,source) VALUES(?,?,'code')").run(c.user.id, row.course_id);
    const course = db.prepare('SELECT id,title FROM courses WHERE id=?').get(row.course_id);
    return { ok: true, course };
  });
});

R('GET', '/api/me/dashboard', 'user', (c) => {
  const courses = db.prepare(`${COURSE_SELECT} JOIN enrollments e ON e.course_id=c.id WHERE e.user_id=? AND c.is_published=1 ORDER BY e.created_at DESC`.replace('FROM courses c JOIN', 'FROM courses c JOIN')).all(c.user.id)
    .map((x) => ({ ...x, enrolled: true, progress: courseProgress(c.user.id, x.id) }));
  const attempts = db.prepare(`SELECT a.id,a.score,a.total,a.submitted_at,q.title,q.pass_percent,q.id quiz_id
      FROM attempts a JOIN quizzes q ON q.id=a.quiz_id WHERE a.user_id=? AND a.submitted_at IS NOT NULL ORDER BY a.submitted_at DESC LIMIT 6`).all(c.user.id);
  const ann = db.prepare('SELECT id,title,body,created_at FROM announcements WHERE is_active=1 AND (grade IS NULL OR grade=?) ORDER BY created_at DESC LIMIT 5').all(c.user.grade || '');
  return { courses, attempts, announcements: ann, grades: GRADES };
});

/* ---------------- quizzes ---------------- */
function quizAccess(user, quizId) {
  const quiz = db.prepare('SELECT * FROM quizzes WHERE id=?').get(quizId);
  if (!quiz || (!quiz.is_published && user.role !== 'admin')) throw E(404, 'الاختبار غير موجود');
  if (!hasAccess(user, quiz.course_id)) throw E(403, 'لازم تشترك في الكورس الأول');
  return quiz;
}
function closeExpired(userId, quiz) {
  const open = db.prepare('SELECT * FROM attempts WHERE user_id=? AND quiz_id=? AND submitted_at IS NULL').all(userId, quiz.id);
  for (const a of open) {
    if (a.started_at + quiz.duration_min * 60 + 60 < Math.floor(Date.now() / 1000)) {
      const total = db.prepare('SELECT COUNT(*) n FROM questions WHERE quiz_id=?').get(quiz.id).n;
      db.prepare("UPDATE attempts SET score=0,total=?,answers='{}',submitted_at=unixepoch() WHERE id=?").run(total, a.id);
    }
  }
}

R('GET', '/api/quizzes/:id', 'user', (c) => {
  const quiz = quizAccess(c.user, c.params.id);
  closeExpired(c.user.id, quiz);
  const attempts = db.prepare('SELECT id,score,total,submitted_at FROM attempts WHERE user_id=? AND quiz_id=? AND submitted_at IS NOT NULL ORDER BY submitted_at DESC').all(c.user.id, quiz.id);
  const questions_count = db.prepare('SELECT COUNT(*) n FROM questions WHERE quiz_id=?').get(quiz.id).n;
  const course = db.prepare('SELECT id,title FROM courses WHERE id=?').get(quiz.course_id);
  return { quiz: { id: quiz.id, title: quiz.title, duration_min: quiz.duration_min, pass_percent: quiz.pass_percent, questions_count }, course, attempts };
});

R('POST', '/api/quizzes/:id/start', 'user', (c) => {
  const quiz = quizAccess(c.user, c.params.id);
  closeExpired(c.user.id, quiz);
  const qs = db.prepare('SELECT id,text,options FROM questions WHERE quiz_id=? ORDER BY sort_order,id').all(quiz.id)
    .map((q) => ({ id: q.id, text: q.text, options: JSON.parse(q.options) }));
  if (!qs.length) throw E(400, 'الاختبار لسه مفيهوش أسئلة');
  let attempt = db.prepare('SELECT * FROM attempts WHERE user_id=? AND quiz_id=? AND submitted_at IS NULL ORDER BY id DESC').get(c.user.id, quiz.id);
  if (!attempt) {
    const r = db.prepare('INSERT INTO attempts(user_id,quiz_id) VALUES(?,?)').run(c.user.id, quiz.id);
    attempt = db.prepare('SELECT * FROM attempts WHERE id=?').get(r.lastInsertRowid);
  }
  const remaining = Math.max(0, attempt.started_at + quiz.duration_min * 60 - Math.floor(Date.now() / 1000));
  return { attempt_id: attempt.id, remaining_seconds: remaining, title: quiz.title, questions: qs };
});

R('POST', '/api/attempts/:id/submit', 'user', (c) => {
  const a = db.prepare('SELECT * FROM attempts WHERE id=? AND user_id=?').get(c.params.id, c.user.id);
  if (!a) throw E(404, 'المحاولة غير موجودة');
  if (a.submitted_at) throw E(409, 'تم تسليم المحاولة دي قبل كده');
  const quiz = db.prepare('SELECT * FROM quizzes WHERE id=?').get(a.quiz_id);
  const late = Math.floor(Date.now() / 1000) > a.started_at + quiz.duration_min * 60 + 60;
  const given = late ? {} : (c.body.answers && typeof c.body.answers === 'object' ? c.body.answers : {});
  const qs = db.prepare('SELECT * FROM questions WHERE quiz_id=? ORDER BY sort_order,id').all(quiz.id);
  let score = 0;
  const review = qs.map((q) => {
    const opts = JSON.parse(q.options);
    const picked = Number.isInteger(given[q.id]) && given[q.id] >= 0 && given[q.id] < opts.length ? given[q.id] : null;
    const correct = picked === q.correct_index;
    if (correct) score++;
    return { id: q.id, text: q.text, options: opts, picked, correct_index: q.correct_index, correct, explanation: q.explanation };
  });
  db.prepare('UPDATE attempts SET score=?,total=?,answers=?,submitted_at=unixepoch() WHERE id=?').run(score, qs.length, JSON.stringify(given), a.id);
  const percent = qs.length ? Math.round((score / qs.length) * 100) : 0;
  return { score, total: qs.length, percent, passed: percent >= quiz.pass_percent, pass_percent: quiz.pass_percent, late, review };
});

/* ------------------------------------------------------------------ */
/* admin                                                               */
/* ------------------------------------------------------------------ */
R('GET', '/api/admin/stats', 'admin', () => {
  const n = (sql) => db.prepare(sql).get().n;
  const byGrade = db.prepare("SELECT grade, COUNT(*) n FROM users WHERE role='student' GROUP BY grade").all();
  return {
    students: n("SELECT COUNT(*) n FROM users WHERE role='student'"),
    students_today: n("SELECT COUNT(*) n FROM users WHERE role='student' AND created_at>=unixepoch('now','start of day')"),
    courses: n('SELECT COUNT(*) n FROM courses'),
    lectures: n('SELECT COUNT(*) n FROM lectures'),
    enrollments: n('SELECT COUNT(*) n FROM enrollments'),
    codes_total: n('SELECT COUNT(*) n FROM codes'),
    codes_used: n('SELECT COUNT(*) n FROM codes WHERE used_by IS NOT NULL'),
    attempts: n('SELECT COUNT(*) n FROM attempts WHERE submitted_at IS NOT NULL'),
    by_grade: GRADES.map((g) => ({ ...g, n: byGrade.find((x) => x.grade === g.id)?.n || 0 })),
    recent_students: db.prepare("SELECT id,name,phone,grade,created_at FROM users WHERE role='student' ORDER BY id DESC LIMIT 6").all(),
    top_courses: db.prepare('SELECT c.id,c.title,(SELECT COUNT(*) FROM enrollments e WHERE e.course_id=c.id) n FROM courses c ORDER BY n DESC LIMIT 5').all()
  };
});

/* ---- courses ---- */
function courseBody(b) {
  if (!gradeIds.includes(b.grade)) throw E(400, 'اختر الصف الدراسي');
  return {
    title: str(b.title, { min: 3, max: 120, label: 'عنوان الكورس' }),
    description: str(b.description, { max: 2000, label: 'الوصف' }),
    grade: b.grade,
    price: int(b.price, { min: 0, max: 100000, label: 'السعر', def: 0 }),
    cover_url: httpUrl(b.cover_url, 'رابط الصورة'),
    is_published: bool(b.is_published)
  };
}
R('GET', '/api/admin/courses', 'admin', () => ({
  courses: db.prepare(`${COURSE_SELECT} ORDER BY c.grade, c.sort_order, c.id`).all(), grades: GRADES
}));
R('POST', '/api/admin/courses', 'admin', (c) => {
  const v = courseBody(c.body);
  const r = db.prepare('INSERT INTO courses(title,description,grade,price,cover_url,is_published,sort_order) VALUES(?,?,?,?,?,?,?)')
    .run(v.title, v.description, v.grade, v.price, v.cover_url, v.is_published, db.prepare('SELECT COALESCE(MAX(sort_order),0)+1 n FROM courses').get().n);
  return { id: r.lastInsertRowid };
});
R('GET', '/api/admin/courses/:id', 'admin', (c) => {
  const course = db.prepare(`${COURSE_SELECT} WHERE c.id=?`).get(c.params.id);
  if (!course) throw E(404, 'الكورس غير موجود');
  return {
    course,
    lectures: db.prepare('SELECT * FROM lectures WHERE course_id=? ORDER BY sort_order,id').all(course.id),
    quizzes: db.prepare('SELECT q.*,(SELECT COUNT(*) FROM questions WHERE quiz_id=q.id) questions_count FROM quizzes q WHERE course_id=? ORDER BY id').all(course.id)
  };
});
R('PUT', '/api/admin/courses/:id', 'admin', (c) => {
  const v = courseBody(c.body);
  const r = db.prepare('UPDATE courses SET title=?,description=?,grade=?,price=?,cover_url=?,is_published=? WHERE id=?')
    .run(v.title, v.description, v.grade, v.price, v.cover_url, v.is_published, c.params.id);
  if (!r.changes) throw E(404, 'الكورس غير موجود');
  return { ok: true };
});
R('DELETE', '/api/admin/courses/:id', 'admin', (c) => {
  db.prepare('DELETE FROM courses WHERE id=?').run(c.params.id);
  return { ok: true };
});

/* ---- lectures ---- */
function lectureBody(b) {
  const video_url = httpUrl(b.video_url, 'رابط الفيديو');
  if (video_url && !L.parseVideo(video_url)) throw E(400, 'رابط الفيديو لازم يكون من يوتيوب أو فيميو أو Bunny أو Google Drive أو ملف mp4');
  return {
    title: str(b.title, { min: 2, max: 150, label: 'عنوان المحاضرة' }),
    description: str(b.description, { max: 3000, label: 'الوصف' }),
    video_url, pdf_url: httpUrl(b.pdf_url, 'رابط المذكرة'),
    duration_min: int(b.duration_min, { min: 0, max: 600, label: 'المدة', def: 0 }),
    is_free: bool(b.is_free), is_published: b.is_published === undefined ? 1 : bool(b.is_published)
  };
}
R('POST', '/api/admin/courses/:id/lectures', 'admin', (c) => {
  if (!db.prepare('SELECT 1 FROM courses WHERE id=?').get(c.params.id)) throw E(404, 'الكورس غير موجود');
  const v = lectureBody(c.body);
  const r = db.prepare('INSERT INTO lectures(course_id,title,description,video_url,pdf_url,duration_min,is_free,is_published,sort_order) VALUES(?,?,?,?,?,?,?,?,?)')
    .run(c.params.id, v.title, v.description, v.video_url, v.pdf_url, v.duration_min, v.is_free, v.is_published, nextOrder('lectures', 'course_id', c.params.id));
  return { id: r.lastInsertRowid };
});
R('PUT', '/api/admin/lectures/:id', 'admin', (c) => {
  const v = lectureBody(c.body);
  const r = db.prepare('UPDATE lectures SET title=?,description=?,video_url=?,pdf_url=?,duration_min=?,is_free=?,is_published=? WHERE id=?')
    .run(v.title, v.description, v.video_url, v.pdf_url, v.duration_min, v.is_free, v.is_published, c.params.id);
  if (!r.changes) throw E(404, 'المحاضرة غير موجودة');
  return { ok: true };
});
R('DELETE', '/api/admin/lectures/:id', 'admin', (c) => {
  db.prepare('DELETE FROM lectures WHERE id=?').run(c.params.id);
  return { ok: true };
});
R('POST', '/api/admin/lectures/:id/move', 'admin', (c) => {
  const lec = db.prepare('SELECT * FROM lectures WHERE id=?').get(c.params.id);
  if (!lec) throw E(404, 'المحاضرة غير موجودة');
  const dir = c.body.dir === 'up' ? -1 : 1;
  const list = db.prepare('SELECT id FROM lectures WHERE course_id=? ORDER BY sort_order,id').all(lec.course_id).map((x) => x.id);
  const i = list.indexOf(lec.id); const j = i + dir;
  if (j < 0 || j >= list.length) return { ok: true };
  [list[i], list[j]] = [list[j], list[i]];
  tx(() => list.forEach((id, k) => db.prepare('UPDATE lectures SET sort_order=? WHERE id=?').run(k + 1, id)));
  return { ok: true };
});

/* ---- quizzes ---- */
function quizBody(b) {
  const questions = Array.isArray(b.questions) ? b.questions : [];
  if (questions.length > 200) throw E(400, 'عدد الأسئلة كبير جدًا');
  const qs = questions.map((q, i) => {
    const opts = (Array.isArray(q.options) ? q.options : []).map((o) => String(o ?? '').trim()).filter(Boolean);
    if (opts.length < 2 || opts.length > 6) throw E(400, `السؤال ${i + 1}: لازم من 2 إلى 6 اختيارات`);
    const ci = int(q.correct_index, { min: 0, max: opts.length - 1, label: `الإجابة الصحيحة في السؤال ${i + 1}` });
    return { text: str(q.text, { min: 1, max: 1000, label: `نص السؤال ${i + 1}` }), options: opts.map((o) => o.slice(0, 300)), correct_index: ci, explanation: str(q.explanation, { max: 1000 }) };
  });
  const is_published = bool(b.is_published);
  if (is_published && !qs.length) throw E(400, 'أضف سؤال واحد على الأقل قبل النشر');
  return {
    title: str(b.title, { min: 2, max: 150, label: 'عنوان الاختبار' }),
    duration_min: int(b.duration_min, { min: 1, max: 300, label: 'مدة الاختبار', def: 15 }),
    pass_percent: int(b.pass_percent, { min: 1, max: 100, label: 'نسبة النجاح', def: 50 }),
    lecture_id: b.lecture_id ? int(b.lecture_id, { min: 1, label: 'المحاضرة' }) : null,
    is_published, qs
  };
}
function saveQuestions(quizId, qs) {
  db.prepare('DELETE FROM questions WHERE quiz_id=?').run(quizId);
  const ins = db.prepare('INSERT INTO questions(quiz_id,text,options,correct_index,explanation,sort_order) VALUES(?,?,?,?,?,?)');
  qs.forEach((q, i) => ins.run(quizId, q.text, JSON.stringify(q.options), q.correct_index, q.explanation, i + 1));
}
function checkLecture(courseId, lectureId) {
  if (lectureId && !db.prepare('SELECT 1 FROM lectures WHERE id=? AND course_id=?').get(lectureId, courseId)) throw E(400, 'المحاضرة مش تابعة للكورس ده');
}
R('POST', '/api/admin/courses/:id/quizzes', 'admin', (c) => {
  if (!db.prepare('SELECT 1 FROM courses WHERE id=?').get(c.params.id)) throw E(404, 'الكورس غير موجود');
  const v = quizBody(c.body);
  checkLecture(c.params.id, v.lecture_id);
  return tx(() => {
    const r = db.prepare('INSERT INTO quizzes(course_id,lecture_id,title,duration_min,pass_percent,is_published) VALUES(?,?,?,?,?,?)')
      .run(c.params.id, v.lecture_id, v.title, v.duration_min, v.pass_percent, v.is_published);
    saveQuestions(r.lastInsertRowid, v.qs);
    return { id: r.lastInsertRowid };
  });
});
R('GET', '/api/admin/quizzes/:id', 'admin', (c) => {
  const quiz = db.prepare('SELECT * FROM quizzes WHERE id=?').get(c.params.id);
  if (!quiz) throw E(404, 'الاختبار غير موجود');
  const questions = db.prepare('SELECT * FROM questions WHERE quiz_id=? ORDER BY sort_order,id').all(quiz.id).map((q) => ({ ...q, options: JSON.parse(q.options) }));
  const lectures = db.prepare('SELECT id,title FROM lectures WHERE course_id=? ORDER BY sort_order,id').all(quiz.course_id);
  return { quiz, questions, lectures };
});
R('PUT', '/api/admin/quizzes/:id', 'admin', (c) => {
  const quiz = db.prepare('SELECT * FROM quizzes WHERE id=?').get(c.params.id);
  if (!quiz) throw E(404, 'الاختبار غير موجود');
  const v = quizBody(c.body);
  checkLecture(quiz.course_id, v.lecture_id);
  tx(() => {
    db.prepare('UPDATE quizzes SET lecture_id=?,title=?,duration_min=?,pass_percent=?,is_published=? WHERE id=?')
      .run(v.lecture_id, v.title, v.duration_min, v.pass_percent, v.is_published, quiz.id);
    saveQuestions(quiz.id, v.qs);
  });
  return { ok: true };
});
R('DELETE', '/api/admin/quizzes/:id', 'admin', (c) => {
  db.prepare('DELETE FROM quizzes WHERE id=?').run(c.params.id);
  return { ok: true };
});

/* ---- codes ---- */
R('POST', '/api/admin/codes', 'admin', (c) => {
  const courseId = int(c.body.course_id, { min: 1, label: 'الكورس' });
  if (!db.prepare('SELECT 1 FROM courses WHERE id=?').get(courseId)) throw E(404, 'الكورس غير موجود');
  const count = int(c.body.count, { min: 1, max: 500, label: 'عدد الأكواد' });
  const batch = new Date().toISOString().slice(0, 16).replace('T', ' ');
  const out = [];
  tx(() => {
    const ins = db.prepare('INSERT OR IGNORE INTO codes(code,course_id,batch) VALUES(?,?,?)');
    while (out.length < count) { const code = genCode(); if (ins.run(code, courseId, batch).changes) out.push(code); }
  });
  return { codes: out };
});
R('GET', '/api/admin/codes', 'admin', (c) => {
  const where = []; const args = [];
  if (c.query.course_id) { where.push('c.course_id=?'); args.push(Number(c.query.course_id)); }
  if (c.query.status === 'used') where.push('c.used_by IS NOT NULL');
  if (c.query.status === 'unused') where.push('c.used_by IS NULL');
  const page = Math.max(1, Number(c.query.page) || 1); const limit = 50;
  const w = where.length ? 'WHERE ' + where.join(' AND ') : '';
  const total = db.prepare(`SELECT COUNT(*) n FROM codes c ${w}`).get(...args).n;
  const rows = db.prepare(`SELECT c.id,c.code,c.batch,c.used_at,c.created_at,co.title course_title,u.name used_by_name,u.phone used_by_phone
      FROM codes c JOIN courses co ON co.id=c.course_id LEFT JOIN users u ON u.id=c.used_by ${w}
      ORDER BY c.id DESC LIMIT ? OFFSET ?`).all(...args, limit, (page - 1) * limit);
  return { codes: rows, total, page, pages: Math.max(1, Math.ceil(total / limit)) };
});
R('GET', '/api/admin/codes.csv', 'admin', (c) => {
  const where = []; const args = [];
  if (c.query.course_id) { where.push('c.course_id=?'); args.push(Number(c.query.course_id)); }
  if (c.query.status === 'unused') where.push('c.used_by IS NULL');
  const rows = db.prepare(`SELECT c.code,co.title,c.batch,u.name,u.phone FROM codes c JOIN courses co ON co.id=c.course_id
     LEFT JOIN users u ON u.id=c.used_by ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY c.id`).all(...args);
  return { raw: toCsv([['الكود', 'الكورس', 'الدفعة', 'استخدمه', 'موبايل'], ...rows.map((r) => [r.code, r.title, r.batch, r.name, r.phone])]), type: 'text/csv; charset=utf-8', filename: 'codes.csv' };
});
R('DELETE', '/api/admin/codes/:id', 'admin', (c) => {
  const r = db.prepare('DELETE FROM codes WHERE id=? AND used_by IS NULL').run(c.params.id);
  if (!r.changes) throw E(400, 'مينفعش تحذف كود مستخدم');
  return { ok: true };
});

/* ---- students ---- */
R('GET', '/api/admin/students', 'admin', (c) => {
  const where = ["role='student'"]; const args = [];
  const q = String(c.query.q || '').trim();
  if (q) { where.push('(name LIKE ? OR phone LIKE ?)'); args.push(`%${q}%`, `%${L.normDigits(q)}%`); }
  if (gradeIds.includes(c.query.grade)) { where.push('grade=?'); args.push(c.query.grade); }
  const page = Math.max(1, Number(c.query.page) || 1); const limit = 25;
  const w = 'WHERE ' + where.join(' AND ');
  const total = db.prepare(`SELECT COUNT(*) n FROM users ${w}`).get(...args).n;
  const rows = db.prepare(`SELECT id,name,phone,parent_phone,grade,is_banned,created_at,last_login,
      (SELECT COUNT(*) FROM enrollments e WHERE e.user_id=users.id) courses_count FROM users ${w} ORDER BY id DESC LIMIT ? OFFSET ?`).all(...args, limit, (page - 1) * limit);
  return { students: rows, total, page, pages: Math.max(1, Math.ceil(total / limit)), grades: GRADES };
});
R('GET', '/api/admin/students.csv', 'admin', () => {
  const rows = db.prepare("SELECT name,phone,parent_phone,grade,created_at FROM users WHERE role='student' ORDER BY id").all();
  const gname = Object.fromEntries(GRADES.map((g) => [g.id, g.name]));
  return { raw: toCsv([['الاسم', 'الموبايل', 'موبايل ولي الأمر', 'الصف', 'تاريخ التسجيل'], ...rows.map((r) => [r.name, r.phone, r.parent_phone, gname[r.grade] || '', new Date(r.created_at * 1000).toISOString().slice(0, 10)])]), type: 'text/csv; charset=utf-8', filename: 'students.csv' };
});
R('GET', '/api/admin/students/:id', 'admin', (c) => {
  const s = db.prepare("SELECT id,name,phone,parent_phone,grade,is_banned,created_at,last_login FROM users WHERE id=? AND role='student'").get(c.params.id);
  if (!s) throw E(404, 'الطالب غير موجود');
  return {
    student: s,
    enrollments: db.prepare('SELECT e.id,e.source,e.created_at,c.id course_id,c.title FROM enrollments e JOIN courses c ON c.id=e.course_id WHERE e.user_id=? ORDER BY e.id DESC').all(s.id)
      .map((e) => ({ ...e, progress: courseProgress(s.id, e.course_id) })),
    attempts: db.prepare('SELECT a.id,a.score,a.total,a.submitted_at,q.title FROM attempts a JOIN quizzes q ON q.id=a.quiz_id WHERE a.user_id=? AND a.submitted_at IS NOT NULL ORDER BY a.submitted_at DESC LIMIT 20').all(s.id),
    devices: db.prepare('SELECT COUNT(*) n FROM sessions WHERE user_id=? AND expires_at>unixepoch()').get(s.id).n,
    courses: db.prepare('SELECT id,title FROM courses ORDER BY grade,sort_order,id').all()
  };
});
R('PUT', '/api/admin/students/:id', 'admin', (c) => {
  const s = db.prepare("SELECT * FROM users WHERE id=? AND role='student'").get(c.params.id);
  if (!s) throw E(404, 'الطالب غير موجود');
  const banned = bool(c.body.is_banned);
  db.prepare('UPDATE users SET is_banned=? WHERE id=?').run(banned, s.id);
  if (banned) db.prepare('DELETE FROM sessions WHERE user_id=?').run(s.id);
  return { ok: true };
});
R('POST', '/api/admin/students/:id/enroll', 'admin', (c) => {
  const courseId = int(c.body.course_id, { min: 1, label: 'الكورس' });
  if (!db.prepare('SELECT 1 FROM courses WHERE id=?').get(courseId)) throw E(404, 'الكورس غير موجود');
  db.prepare("INSERT OR IGNORE INTO enrollments(user_id,course_id,source) VALUES(?,?,'admin')").run(c.params.id, courseId);
  return { ok: true };
});
R('DELETE', '/api/admin/enrollments/:id', 'admin', (c) => {
  db.prepare('DELETE FROM enrollments WHERE id=?').run(c.params.id);
  return { ok: true };
});
R('POST', '/api/admin/students/:id/reset-password', 'admin', async (c) => {
  const pw = String(c.body.password ?? '');
  if (pw.length < 6 || pw.length > 72) throw E(400, 'كلمة المرور لازم تكون من 6 إلى 72 حرف');
  const r = db.prepare("UPDATE users SET password_hash=? WHERE id=? AND role='student'").run(await L.hashPassword(pw), c.params.id);
  if (!r.changes) throw E(404, 'الطالب غير موجود');
  db.prepare('DELETE FROM sessions WHERE user_id=?').run(c.params.id);
  return { ok: true };
});
R('POST', '/api/admin/students/:id/logout-devices', 'admin', (c) => {
  db.prepare('DELETE FROM sessions WHERE user_id=?').run(c.params.id);
  return { ok: true };
});

/* ---- announcements ---- */
R('GET', '/api/admin/announcements', 'admin', () => ({ announcements: db.prepare('SELECT * FROM announcements ORDER BY id DESC').all(), grades: GRADES }));
R('POST', '/api/admin/announcements', 'admin', (c) => {
  const grade = c.body.grade && gradeIds.includes(c.body.grade) ? c.body.grade : null;
  const r = db.prepare('INSERT INTO announcements(title,body,grade,is_active) VALUES(?,?,?,?)')
    .run(str(c.body.title, { min: 2, max: 150, label: 'العنوان' }), str(c.body.body, { max: 1500 }), grade, c.body.is_active === undefined ? 1 : bool(c.body.is_active));
  return { id: r.lastInsertRowid };
});
R('PUT', '/api/admin/announcements/:id', 'admin', (c) => {
  const grade = c.body.grade && gradeIds.includes(c.body.grade) ? c.body.grade : null;
  db.prepare('UPDATE announcements SET title=?,body=?,grade=?,is_active=? WHERE id=?')
    .run(str(c.body.title, { min: 2, max: 150, label: 'العنوان' }), str(c.body.body, { max: 1500 }), grade, bool(c.body.is_active), c.params.id);
  return { ok: true };
});
R('DELETE', '/api/admin/announcements/:id', 'admin', (c) => {
  db.prepare('DELETE FROM announcements WHERE id=?').run(c.params.id);
  return { ok: true };
});

/* ---- settings ---- */
R('GET', '/api/admin/settings', 'admin', () => ({ settings: getSettings() }));
R('PUT', '/api/admin/settings', 'admin', (c) => {
  const up = db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
  tx(() => {
    for (const k of Object.keys(DEFAULT_SETTINGS)) {
      if (c.body[k] === undefined) continue;
      const urlKeys = ['teacher_photo', 'facebook', 'youtube', 'telegram'];
      let v = urlKeys.includes(k) ? httpUrl(c.body[k], k) : str(c.body[k], { max: k === 'teacher_bio' ? 1500 : 200 });
      if (k === 'whatsapp' || k === 'support_phone') v = L.normPhone(v);
      up.run(k, v);
    }
  });
  return { ok: true };
});

export function adminExists() {
  return !!db.prepare("SELECT 1 FROM users WHERE role='admin'").get();
}
export async function createAdmin(name, phone, password) {
  const hash = await L.hashPassword(password);
  db.prepare("INSERT INTO users(name,phone,password_hash,role) VALUES(?,?,?,'admin')").run(name, phone, hash);
}
