import crypto from 'node:crypto';
import { promisify } from 'node:util';

const scrypt = promisify(crypto.scrypt);

export class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
export const E = (status, msg) => new HttpError(status, msg);

/* ---------- passwords ---------- */
export async function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(pw, salt, 64);
  return `s1$${salt.toString('hex')}$${key.toString('hex')}`;
}
export async function verifyPassword(pw, stored) {
  const [v, s, k] = String(stored).split('$');
  if (v !== 's1' || !s || !k) return false;
  const key = await scrypt(pw, Buffer.from(s, 'hex'), 64);
  const exp = Buffer.from(k, 'hex');
  return key.length === exp.length && crypto.timingSafeEqual(key, exp);
}
export const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
export const newToken = () => crypto.randomBytes(32).toString('base64url');

/* ---------- phones ---------- */
export function normDigits(s) {
  return String(s ?? '')
    .replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d))
    .replace(/[۰-۹]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d))
    .replace(/[\s\-+()]/g, '');
}
export function normPhone(s) {
  let p = normDigits(s);
  if (p.startsWith('0020')) p = '0' + p.slice(4);
  else if (p.startsWith('20') && p.length === 12) p = '0' + p.slice(2);
  return p;
}
export const isEgPhone = (p) => /^01[0125]\d{8}$/.test(p);

/* ---------- validators ---------- */
export function str(v, { min = 0, max = 500, label = 'الحقل' } = {}) {
  v = String(v ?? '').trim();
  if (v.length < min) throw E(400, min === 1 ? `${label} مطلوب` : `${label} قصير جدًا`);
  if (v.length > max) throw E(400, `${label} طويل جدًا`);
  return v;
}
export function int(v, { min = 0, max = 1e9, label = 'الرقم', def } = {}) {
  if ((v === undefined || v === null || v === '') && def !== undefined) return def;
  const n = Number(v);
  if (!Number.isInteger(n) || n < min || n > max) throw E(400, `${label} غير صحيح`);
  return n;
}
export const bool = (v) => (v === true || v === 1 || v === '1' || v === 'true' ? 1 : 0);
export function httpUrl(v, label = 'الرابط') {
  v = String(v ?? '').trim();
  if (!v) return '';
  if (v.length > 800) throw E(400, `${label} طويل جدًا`);
  try {
    const u = new URL(v);
    if (u.protocol !== 'https:' && u.protocol !== 'http:') throw 0;
  } catch { throw E(400, `${label} لازم يكون رابط صحيح`); }
  return v;
}

/* ---------- video links ---------- */
export function parseVideo(url) {
  url = String(url || '').trim();
  if (!url) return null;
  let u;
  try { u = new URL(url); } catch { return null; }
  if (u.protocol !== 'https:') return null;
  const h = u.hostname.replace(/^www\./, '');
  let id;
  if (h === 'youtu.be') id = u.pathname.slice(1).split('/')[0];
  else if (h === 'youtube.com' || h === 'm.youtube.com' || h === 'youtube-nocookie.com') {
    id = u.searchParams.get('v') || (u.pathname.match(/^\/(?:embed|shorts|live)\/([\w-]{11})/) || [])[1];
  }
  if (id && /^[\w-]{11}$/.test(id)) {
    return { type: 'youtube', src: `https://www.youtube-nocookie.com/embed/${id}?rel=0&modestbranding=1&playsinline=1&iv_load_policy=3` };
  }
  if (h === 'vimeo.com' || h === 'player.vimeo.com') {
    const m = u.pathname.match(/(\d{6,})/);
    if (m) return { type: 'vimeo', src: `https://player.vimeo.com/video/${m[1]}${u.searchParams.get('h') ? '?h=' + encodeURIComponent(u.searchParams.get('h')) : ''}` };
  }
  if (h === 'iframe.mediadelivery.net' && u.pathname.startsWith('/embed/')) return { type: 'bunny', src: url };
  if (h === 'drive.google.com') {
    const m = u.pathname.match(/\/file\/d\/([\w-]+)/);
    if (m) return { type: 'drive', src: `https://drive.google.com/file/d/${m[1]}/preview` };
  }
  if (/\.(mp4|webm)$/i.test(u.pathname)) return { type: 'file', src: url };
  return null;
}

/* ---------- rate limit ---------- */
const buckets = new Map();
export function rateLimit(key, max, windowMs) {
  const now = Date.now();
  let b = buckets.get(key);
  if (!b || b.reset < now) { b = { n: 0, reset: now + windowMs }; buckets.set(key, b); }
  b.n++;
  if (b.n > max) throw E(429, 'محاولات كتير، استنى شوية وحاول تاني');
}
setInterval(() => { const now = Date.now(); for (const [k, b] of buckets) if (b.reset < now) buckets.delete(k); }, 60000).unref();

/* ---------- http helpers ---------- */
export function parseCookies(req) {
  const out = {};
  for (const part of String(req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}
export async function readJson(req, limit = 2_000_000) {
  const chunks = []; let size = 0;
  for await (const c of req) {
    size += c.length;
    if (size > limit) throw E(413, 'الطلب كبير جدًا');
    chunks.push(c);
  }
  if (!size) return {};
  try { const v = JSON.parse(Buffer.concat(chunks).toString('utf8')); return v && typeof v === 'object' ? v : {}; }
  catch { throw E(400, 'بيانات غير صالحة'); }
}
export function clientIp(req) {
  if (process.env.TRUST_PROXY === '1') {
    const xf = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (xf) return xf;
  }
  return req.socket.remoteAddress || 'unknown';
}
