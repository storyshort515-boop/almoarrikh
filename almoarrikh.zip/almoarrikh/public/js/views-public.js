import { html, raw, bind, $, num, fmtMin, price, waLink, safeUrl, spinner, emptyBox, toast, fmtDate } from './ui.js';
import { state, get, post, navigate, refreshUser, fail } from './core.js';

const ERAS = [
  { t: 'مصر القديمة', d: 'حتى 332 ق.م', x: 'حضارة نشأت على ضفاف النيل وحكمتها الأسرات الفرعونية آلاف السنين.' },
  { t: 'اليوناني والروماني', d: '332 ق.م - 641 م', x: 'بدأ بدخول الإسكندر الأكبر مصر، وانتهى بالفتح الإسلامي.' },
  { t: 'الفتح الإسلامي', d: 'منذ 640 م', x: 'فتح عمرو بن العاص مصر وأسس الفسطاط عاصمة جديدة.' },
  { t: 'الحكم العثماني', d: 'منذ 1517', x: 'ضم السلطان سليم الأول مصر إلى الدولة العثمانية بعد معركة الريدانية.' },
  { t: 'الحملة الفرنسية', d: '1798 - 1801', x: 'قادها نابليون بونابرت، وفتحت باب الاحتكاك المباشر بين مصر وأوروبا.' },
  { t: 'محمد علي', d: 'منذ 1805', x: 'اختاره العلماء والأعيان واليًا على مصر، وبدأ بناء الدولة الحديثة.' },
  { t: 'الاحتلال البريطاني', d: '1882', x: 'احتلت بريطانيا مصر بعد هزيمة الجيش المصري في التل الكبير.' },
  { t: 'ثورة 1919', d: '1919', x: 'ثورة شعبية اندلعت بعد نفي سعد زغلول ورفاقه، وطالبت بالاستقلال.' },
  { t: 'ثورة 23 يوليو', d: '1952', x: 'أنهت حكم الأسرة العلوية، وأُعلنت الجمهورية بعد ذلك بعام.' }
];

export const logoSvg = raw(`<svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="34" r="22" fill="none" stroke="#d6ad5a" stroke-width="2"/><path d="M32 8 L37 20 L36 52 H28 L27 20 Z" fill="#d6ad5a"/><path d="M17 52 H47" stroke="#d6ad5a" stroke-width="3.5" stroke-linecap="round"/></svg>`);

export function courseCard(c, grades) {
  const g = grades.find((x) => x.id === c.grade);
  return html`<a class="card course-card" href="#/course/${c.id}">
    <div class="cover ${c.grade}">
      ${safeUrl(c.cover_url) ? html`<img src="${c.cover_url}" alt="" loading="lazy">` : ''}
      ${c.enrolled ? html`<span class="badge ok">مشترك</span>` : html`<span class="badge gold">${g?.short || ''}</span>`}
      ${safeUrl(c.cover_url) ? '' : html`<h3>${c.title}</h3>`}
    </div>
    <div class="cc-body">
      ${safeUrl(c.cover_url) ? html`<h3>${c.title}</h3>` : ''}
      <p class="muted small" style="display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">${c.description || 'كورس تاريخ كامل مع الأستاذ سعيد إسماعيل.'}</p>
      <div class="meta"><span>${num(c.lectures_count)} محاضرة</span>${c.total_minutes ? html`<span>${fmtMin(c.total_minutes)}</span>` : ''}</div>
      <div class="cc-foot"><span class="price">${c.enrolled ? html`<small>تابع المذاكرة</small>` : price(c.price)}</span><span class="btn btn-sm">${c.enrolled ? 'ادخل الكورس' : 'التفاصيل'}</span></div>
    </div>
  </a>`;
}

/* ============================ الرئيسية ============================ */
export async function home(root) {
  root.innerHTML = spinner().s;
  const d = await get('/home');
  state.settings = d.settings;
  const s = d.settings;
  const first = d.grades;
  root.innerHTML = html`
  <section class="hero">
    <div class="wrap">
      <h1>${s.teacher_nick}</h1>
      <p class="sub">منصة الأستاذ ${s.teacher_name} لتاريخ الثانوي العام</p>
      <p class="tag">${s.tagline}</p>
      <div class="cta">
        ${state.user ? html`<a class="btn btn-gold btn-lg" href="#/me">كمّل مذاكرتك</a>` : html`<a class="btn btn-gold btn-lg" href="#/register">سجّل حسابك مجانًا</a>`}
        <a class="btn btn-light btn-lg" href="#/courses">تصفح الكورسات</a>
      </div>
      <div class="hero-stats">
        <div><b>${num(d.stats.students)}</b>طالب مسجل</div>
        <div><b>${num(d.stats.courses)}</b>كورس</div>
        <div><b>${num(d.stats.lectures)}</b>محاضرة</div>
      </div>
      <div class="tl" aria-label="خط زمني لتاريخ مصر">
        <div class="tl-track" role="tablist">${ERAS.map((e, i) => html`<button class="tl-node${i === 4 ? ' on' : ''}" role="tab" data-i="${i}"><i></i><b>${e.t}</b><span>${e.d}</span></button>`)}</div>
        <div class="tl-info" id="tl-info" aria-live="polite"></div>
      </div>
    </div>
  </section>

  ${d.announcements.length ? html`<section class="section" style="padding-bottom:0"><div class="wrap">${d.announcements.map((a) => html`<div class="ann"><div><b>${a.title}</b>${a.body ? html`<span>${a.body}</span>` : ''}</div></div>`)}</div></section>` : ''}

  <section class="section">
    <div class="wrap">
      <div class="sec-head"><div><h2>اختار صفك الدراسي</h2><p>كل صف له كورساته ومحاضراته واختباراته.</p></div></div>
      <div class="grid c3">
        ${first.map((g, i) => html`<a class="grade-card gc-${g.id}" href="#/courses?grade=${g.id}"><h3>${g.name}</h3><span>شوف الكورسات المتاحة</span><span class="n">${['١', '٢', '٣'][i]}</span></a>`)}
      </div>
    </div>
  </section>

  <section class="section alt">
    <div class="wrap">
      <div class="sec-head"><div><h2>أحدث الكورسات</h2></div><a class="btn btn-ghost" href="#/courses">كل الكورسات</a></div>
      ${d.courses.length ? html`<div class="grid c3">${d.courses.map((c) => courseCard(c, d.grades))}</div>` : emptyBox('الكورسات هتنزل قريب', 'سجّل حسابك دلوقتي وهنبلغك أول ما أول كورس يتنشر.')}
    </div>
  </section>

  <section class="section">
    <div class="wrap">
      <div class="sec-head"><div><h2>إزاي تذاكر على المنصة؟</h2></div></div>
      <div class="steps">
        <div class="step"><h3>سجّل حسابك</h3><p class="muted">اكتب بياناتك وبيانات ولي الأمر واختار صفك.</p></div>
        <div class="step"><h3>اشترِ كود الكورس</h3><p class="muted">الكود بتاخده من الأستاذ أو من مراكز البيع، وكل كود بيفتح كورس واحد.</p></div>
        <div class="step"><h3>فعّل الكود</h3><p class="muted">اكتب الكود في صفحة الكورس والمحاضرات تتفتح فورًا على حسابك.</p></div>
        <div class="step"><h3>ذاكر واختبر نفسك</h3><p class="muted">شاهد المحاضرة، حمّل المذكرة، وحل الاختبار وشوف نتيجتك والتصحيح.</p></div>
      </div>
    </div>
  </section>

  <section class="section alt">
    <div class="wrap">
      <div class="teacher">
        <div class="t-photo">${safeUrl(s.teacher_photo) ? html`<img src="${s.teacher_photo}" alt="${s.teacher_name}">` : s.teacher_name.trim()[0]}</div>
        <div>
          <h2>الأستاذ ${s.teacher_name}</h2>
          <p>${s.teacher_bio}</p>
          <div class="social">
            ${s.whatsapp ? html`<a class="btn" target="_blank" rel="noopener" href="${waLink(s.whatsapp, 'مرحبًا، عندي استفسار عن منصة المؤرخ')}">واتساب</a>` : ''}
            ${safeUrl(s.youtube) ? html`<a class="btn btn-ghost" target="_blank" rel="noopener" href="${s.youtube}">يوتيوب</a>` : ''}
            ${safeUrl(s.facebook) ? html`<a class="btn btn-ghost" target="_blank" rel="noopener" href="${s.facebook}">فيسبوك</a>` : ''}
            ${safeUrl(s.telegram) ? html`<a class="btn btn-ghost" target="_blank" rel="noopener" href="${s.telegram}">تيليجرام</a>` : ''}
          </div>
        </div>
      </div>
    </div>
  </section>`.s;

  const info = $('#tl-info', root);
  const show = (i) => {
    const e = ERAS[i];
    info.innerHTML = html`<b>${e.t}</b>${e.x}`.s;
    root.querySelectorAll('.tl-node').forEach((n, k) => { n.classList.toggle('on', k === i); n.setAttribute('aria-selected', k === i); });
  };
  show(4);
  bind(root, 'click', '.tl-node', (e, t) => show(Number(t.dataset.i)));
  // ابدأ بالعقدة المختارة ظاهرة على الموبايل
  requestAnimationFrame(() => root.querySelector('.tl-node.on')?.scrollIntoView({ inline: 'center', block: 'nearest' }));
}

/* ============================ دخول / تسجيل ============================ */
export async function login(root, { query }) {
  if (state.user) return navigate('/me');
  root.innerHTML = html`<div class="card auth">
    <h1>تسجيل الدخول</h1><p class="muted" style="margin-bottom:20px">ادخل برقم موبايلك وكلمة المرور.</p>
    <form id="f" novalidate><div id="err"></div>
      <div class="field"><label for="phone">رقم الموبايل</label><input class="input" id="phone" name="phone" inputmode="tel" autocomplete="username" dir="ltr" style="text-align:right" placeholder="01xxxxxxxxx" required></div>
      <div class="field"><label for="password">كلمة المرور</label><input class="input" id="password" name="password" type="password" autocomplete="current-password" required></div>
      <button class="btn btn-block btn-lg" type="submit">دخول</button>
    </form>
    <p class="center muted" style="margin-top:18px">لسه معندكش حساب؟ <a href="#/register" style="color:var(--lapis);font-weight:600">سجّل دلوقتي</a></p>
  </div>`.s;
  const f = $('#f', root);
  f.onsubmit = async (e) => {
    e.preventDefault();
    const b = f.querySelector('button'); b.disabled = true;
    try {
      const r = await post('/auth/login', { phone: f.phone.value, password: f.password.value });
      state.user = r.user; window.dispatchEvent(new Event('auth-changed'));
      navigate(query.next || (r.user.role === 'admin' ? '/admin' : '/me'));
    } catch (er) { $('#err', root).innerHTML = html`<div class="err">${er.message}</div>`.s; b.disabled = false; }
  };
}

export async function register(root) {
  if (state.user) return navigate('/me');
  const { grades } = await get('/courses?grade=none');
  root.innerHTML = html`<div class="card auth">
    <h1>إنشاء حساب جديد</h1><p class="muted" style="margin-bottom:20px">التسجيل مجاني، وبعدها تقدر تفعّل كود أي كورس.</p>
    <form id="f" novalidate><div id="err"></div>
      <div class="field"><label for="name">الاسم بالكامل</label><input class="input" id="name" name="name" autocomplete="name" required></div>
      <div class="two">
        <div class="field"><label for="phone">موبايلك</label><input class="input" id="phone" name="phone" inputmode="tel" autocomplete="tel" dir="ltr" style="text-align:right" placeholder="01xxxxxxxxx" required></div>
        <div class="field"><label for="parent_phone">موبايل ولي الأمر</label><input class="input" id="parent_phone" name="parent_phone" inputmode="tel" dir="ltr" style="text-align:right" placeholder="01xxxxxxxxx" required></div>
      </div>
      <div class="field"><label for="grade">الصف الدراسي</label><select class="select" id="grade" name="grade" required><option value="">اختار صفك</option>${grades.map((g) => html`<option value="${g.id}">${g.name}</option>`)}</select></div>
      <div class="two">
        <div class="field"><label for="password">كلمة المرور</label><input class="input" id="password" name="password" type="password" autocomplete="new-password" minlength="6" required><span class="hint">6 أحرف على الأقل</span></div>
        <div class="field"><label for="password2">تأكيد كلمة المرور</label><input class="input" id="password2" name="password2" type="password" autocomplete="new-password" required></div>
      </div>
      <button class="btn btn-block btn-lg" type="submit">إنشاء الحساب</button>
    </form>
    <p class="center muted" style="margin-top:18px">عندك حساب؟ <a href="#/login" style="color:var(--lapis);font-weight:600">سجّل دخولك</a></p>
  </div>`.s;
  const f = $('#f', root);
  f.onsubmit = async (e) => {
    e.preventDefault();
    const err = (m) => { $('#err', root).innerHTML = html`<div class="err">${m}</div>`.s; };
    if (f.password.value !== f.password2.value) return err('كلمتا المرور مش متطابقتين');
    const b = f.querySelector('button'); b.disabled = true;
    try {
      const r = await post('/auth/register', { name: f.name.value, phone: f.phone.value, parent_phone: f.parent_phone.value, grade: f.grade.value, password: f.password.value });
      state.user = r.user; window.dispatchEvent(new Event('auth-changed'));
      toast('أهلًا بيك في المنصة!'); navigate('/courses?grade=' + r.user.grade);
    } catch (er) { err(er.message); b.disabled = false; }
  };
}

/* ============================ الكورسات ============================ */
export async function courses(root, { query }) {
  root.innerHTML = spinner().s;
  const g = query.grade || (state.user?.grade && state.user.role !== 'admin' ? state.user.grade : '');
  const d = await get('/courses' + (g ? `?grade=${g}` : ''));
  root.innerHTML = html`
  <div class="page-head"><div class="wrap"><h1>الكورسات</h1><p>اختار صفك وابدأ المذاكرة.</p></div></div>
  <section class="section"><div class="wrap">
    <div class="tabs" role="tablist"><a class="tab${!g ? ' on' : ''}" href="#/courses?grade=">الكل</a>${d.grades.map((x) => html`<a class="tab${g === x.id ? ' on' : ''}" href="#/courses?grade=${x.id}">${x.name}</a>`)}</div>
    ${d.courses.length ? html`<div class="grid c3">${d.courses.map((c) => courseCard(c, d.grades))}</div>` : emptyBox('مفيش كورسات هنا لسه', 'الكورسات الجديدة بتنزل أول بأول، ارجع تاني قريب.')}
  </div></section>`.s;
}

/* ============================ صفحة الكورس ============================ */
export async function course(root, { params }) {
  root.innerHTML = spinner().s;
  const d = await get(`/courses/${params.id}`);
  const c = d.course;
  const grades = (await get('/courses?grade=none')).grades;
  const g = grades.find((x) => x.id === c.grade);
  const buyMsg = `مرحبًا، عايز كود كورس "${c.title}" على منصة المؤرخ`;
  root.innerHTML = html`
  <div class="page-head"><div class="wrap">
    <div class="crumbs"><a href="#/">الرئيسية</a> / <a href="#/courses?grade=${c.grade}">${g?.name}</a></div>
    <h1>${c.title}</h1>
    ${c.description ? html`<p>${c.description}</p>` : ''}
  </div></div>
  <div class="wrap split">
    <div>
      <div class="card" style="overflow:hidden">
        <div style="padding:16px 18px;border-bottom:1px solid var(--line)" class="row"><b class="grow">محتوى الكورس</b><span class="muted small">${num(d.lectures.length)} محاضرة ${c.total_minutes ? '، ' + fmtMin(c.total_minutes) : ''}</span></div>
        ${d.lectures.length ? d.lectures.map((l, i) => {
          const inner = html`<span class="no">${l.completed ? '✓' : num(i + 1)}</span>
            <span class="t"><b>${l.title}</b><span class="muted small">${l.duration_min ? fmtMin(l.duration_min) : ''}</span></span>
            ${l.is_free && !c.enrolled ? html`<span class="badge ok">مجانية</span>` : ''}${l.locked ? html`<span class="muted" title="مقفولة">مقفولة</span>` : ''}`;
          return l.locked ? html`<div class="lec locked">${inner}</div>` : html`<a class="lec${l.completed ? ' done' : ''}" href="#/lecture/${l.id}">${inner}</a>`;
        }) : emptyBox('المحاضرات جاية قريب', 'لسه مفيش محاضرات منشورة في الكورس ده.')}
      </div>
      ${d.quizzes.length ? html`<div class="card" style="margin-top:20px;overflow:hidden"><div style="padding:16px 18px;border-bottom:1px solid var(--line)"><b>الاختبارات</b></div>
        ${d.quizzes.map((q) => q.locked
          ? html`<div class="lec locked"><span class="t"><b>${q.title}</b><span class="muted small">${num(q.questions_count)} سؤال</span></span><span>مقفول</span></div>`
          : html`<a class="lec" href="#/quiz/${q.id}"><span class="t"><b>${q.title}</b><span class="muted small">${num(q.questions_count)} سؤال، ${num(q.duration_min)} دقيقة</span></span><span class="btn btn-sm">ابدأ</span></a>`)}</div>` : ''}
    </div>
    <aside class="card side-card stack">
      ${c.enrolled ? html`
        <span class="badge ok">أنت مشترك في الكورس</span>
        ${d.progress ? html`<div><div class="row small" style="justify-content:space-between"><span>تقدمك</span><b>${num(d.progress.percent)}%</b></div><div class="progress"><i style="width:${d.progress.percent}%"></i></div><p class="muted small">${num(d.progress.done)} من ${num(d.progress.total)} محاضرة</p></div>` : ''}
        ${d.lectures.find((l) => !l.completed && !l.locked) ? html`<a class="btn btn-block" href="#/lecture/${d.lectures.find((l) => !l.completed && !l.locked).id}">كمّل من حيث وقفت</a>` : ''}`
      : html`
        <div class="price" style="font-size:2rem">${price(c.price)}</div>
        ${state.user ? html`<form id="redeem" novalidate>
          <div id="rerr"></div>
          <div class="field" style="margin-bottom:10px"><label for="code">عندك كود الكورس؟</label><input class="input mono" id="code" dir="ltr" placeholder="XXXX-XXXX-XXXX" autocomplete="off" maxlength="20" required></div>
          <button class="btn btn-block" type="submit">تفعيل الكود</button></form>`
        : html`<a class="btn btn-block btn-lg" href="#/login?next=${encodeURIComponent('/course/' + c.id)}">سجّل دخولك عشان تشترك</a>`}
        ${d.settings.whatsapp ? html`<a class="btn btn-ghost btn-block" target="_blank" rel="noopener" href="${waLink(d.settings.whatsapp, buyMsg)}">اطلب الكود على واتساب</a>` : ''}`}
    </aside>
  </div>`.s;

  const f = $('#redeem', root);
  if (f) f.onsubmit = async (e) => {
    e.preventDefault();
    const b = f.querySelector('button'); b.disabled = true;
    try { await post('/redeem', { code: $('#code', f).value }); toast('تم تفعيل الكورس، ذاكر كويس!'); course(root, { params }); }
    catch (er) { $('#rerr', f).innerHTML = html`<div class="err">${er.message}</div>`.s; b.disabled = false; }
  };
}
