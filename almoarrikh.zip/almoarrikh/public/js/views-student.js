import { html, raw, bind, $, num, fmtMin, fmtDateTime, price, spinner, emptyBox, toast, safeUrl, formModal, esc } from './ui.js';
import { state, get, post, navigate, fail, logout } from './core.js';
import { courseCard } from './views-public.js';

/* ============================ لوحة الطالب ============================ */
export async function me(root) {
  root.innerHTML = spinner().s;
  const d = await get('/me/dashboard');
  const u = state.user;
  const g = d.grades.find((x) => x.id === u.grade);
  root.innerHTML = html`
  <div class="dash-head"><div class="wrap">
    <h1>أهلًا يا ${u.name.split(' ')[0]}</h1>
    <p style="color:#cdd2e6">${g?.name || ''}</p>
  </div></div>
  <div class="wrap" style="padding:32px 0 64px">
    ${d.announcements.map((a) => html`<div class="ann"><div><b>${a.title}</b>${a.body ? html`<span>${a.body}</span>` : ''}</div></div>`)}
    <div class="sec-head" style="margin-top:28px"><div><h2>كورساتي</h2></div><a class="btn btn-ghost" href="#/courses?grade=${u.grade}">تصفح كورسات صفي</a></div>
    ${d.courses.length ? html`<div class="grid c3">${d.courses.map((c) => html`<a class="card course-card" href="#/course/${c.id}">
        <div class="cover ${c.grade}">${safeUrl(c.cover_url) ? html`<img src="${c.cover_url}" alt="" loading="lazy">` : html`<h3>${c.title}</h3>`}</div>
        <div class="cc-body"><b>${safeUrl(c.cover_url) ? c.title : ''}</b>
          <div class="progress"><i style="width:${c.progress.percent}%"></i></div>
          <div class="row small muted" style="justify-content:space-between"><span>${num(c.progress.done)} من ${num(c.progress.total)} محاضرة</span><b>${num(c.progress.percent)}%</b></div>
        </div></a>`)}</div>`
      : html`<div class="card">${emptyBox('لسه مشتركتش في أي كورس', 'اختار كورس من صفحة الكورسات وفعّل الكود بتاعه.', html`<a class="btn" href="#/courses?grade=${u.grade}">شوف الكورسات</a>`)}</div>`}

    <div class="grid c2" style="margin-top:36px">
      <div>
        <div class="sec-head"><div><h2>آخر الاختبارات</h2></div></div>
        ${d.attempts.length ? html`<div class="card">${d.attempts.map((a) => {
          const p = a.total ? Math.round((a.score / a.total) * 100) : 0;
          return html`<a class="lec" href="#/quiz/${a.quiz_id}"><span class="t"><b>${a.title}</b><span class="muted small">${fmtDateTime(a.submitted_at)}</span></span><span class="badge ${p >= a.pass_percent ? 'ok' : 'bad'}">${num(a.score)} / ${num(a.total)}</span></a>`;
        })}</div>` : html`<div class="card">${emptyBox('مفيش اختبارات لسه', 'اختبر نفسك بعد كل محاضرة.')}</div>`}
      </div>
      <div>
        <div class="sec-head"><div><h2>حسابي</h2></div></div>
        <div class="card" style="padding:20px">
          <p><b>${u.name}</b></p>
          <p class="muted ltr" style="text-align:start;direction:ltr">${u.phone}</p>
          <div class="row" style="margin-top:14px"><button class="btn btn-ghost btn-sm" id="pw">تغيير كلمة المرور</button><button class="btn btn-ghost btn-sm" id="out">تسجيل الخروج</button></div>
        </div>
      </div>
    </div>
  </div>`.s;

  $('#out', root).onclick = logout;
  $('#pw', root).onclick = () => formModal({
    title: 'تغيير كلمة المرور', submitText: 'حفظ',
    fields: [
      { name: 'current', label: 'كلمة المرور الحالية', type: 'password', required: true },
      { name: 'next', label: 'كلمة المرور الجديدة', type: 'password', required: true, hint: '6 أحرف على الأقل' }
    ],
    submit: async (v) => { await post('/auth/change-password', v); toast('تم تغيير كلمة المرور'); }
  });
}

/* ============================ المحاضرة ============================ */
export async function lecture(root, { params }) {
  root.innerHTML = spinner().s;
  let d;
  try { d = await get(`/lectures/${params.id}`); }
  catch (e) {
    if (e.status === 403) {
      root.innerHTML = html`<div class="wrap"><div class="card" style="margin:48px auto;max-width:520px">${emptyBox('المحاضرة دي مقفولة', 'لازم تشترك في الكورس الأول عشان تشوفها.', html`<button class="btn" onclick="history.back()">رجوع</button>`)}</div></div>`.s;
      return;
    }
    throw e;
  }
  const l = d.lecture;
  const v = l.video;
  const player = !v ? html`<div class="empty"><p>الفيديو لسه متاحش للمحاضرة دي.</p></div>`
    : v.type === 'file' ? html`<video controls controlsList="nodownload" playsinline preload="metadata" src="${v.src}"></video>`
    : html`<iframe src="${v.src}" title="${l.title}" allow="accelerometer; encrypted-media; gyroscope; picture-in-picture; fullscreen" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe>`;
  root.innerHTML = html`
  <div class="wrap lecture-grid">
    <div class="stack">
      <div class="crumbs muted small"><a href="#/course/${d.course.id}">${d.course.title}</a></div>
      <div class="player">${player}${v ? html`<div class="wm" aria-hidden="true">${d.watermark}</div>` : ''}</div>
      <div class="row" style="justify-content:space-between;margin-top:16px">
        <h1 style="font-family:var(--display);font-size:1.7rem">${l.title}</h1>
        <button class="btn ${l.completed ? 'btn-ok' : 'btn-ghost'}" id="done">${l.completed ? '✓ تمت المشاهدة' : 'علّم كمشاهدة'}</button>
      </div>
      ${l.duration_min ? html`<p class="muted small">${fmtMin(l.duration_min)}</p>` : ''}
      ${l.description ? html`<p style="white-space:pre-line">${l.description}</p>` : ''}
      ${safeUrl(l.pdf_url) ? html`<a class="btn btn-gold" href="${l.pdf_url}" target="_blank" rel="noopener noreferrer">تحميل المذكرة PDF</a>` : ''}
      ${d.quizzes.length ? html`<div class="card" style="margin-top:8px;overflow:hidden"><div style="padding:14px 18px;border-bottom:1px solid var(--line)"><b>اختبر نفسك على المحاضرة</b></div>
        ${d.quizzes.map((q) => html`<a class="lec" href="#/quiz/${q.id}"><span class="t"><b>${q.title}</b><span class="muted small">${num(q.questions_count)} سؤال، ${num(q.duration_min)} دقيقة</span></span><span class="btn btn-sm">ابدأ</span></a>`)}</div>` : ''}
      <div class="row" style="justify-content:space-between;margin-top:8px">
        ${d.prev ? html`<a class="btn btn-ghost" href="#/lecture/${d.prev}">المحاضرة السابقة</a>` : html`<span></span>`}
        ${d.next ? html`<a class="btn" href="#/lecture/${d.next}">المحاضرة التالية</a>` : ''}
      </div>
    </div>
    <aside class="card"><div style="padding:14px 18px;border-bottom:1px solid var(--line)"><b>محاضرات الكورس</b></div>
      <div class="playlist">${d.playlist.map((x, i) => {
        const inner = html`<span class="no">${x.completed ? '✓' : num(i + 1)}</span><span class="t"><b>${x.title}</b></span>`;
        return x.locked ? html`<div class="lec locked">${inner}</div>` : html`<a class="lec${x.completed ? ' done' : ''}${x.id === l.id ? ' cur' : ''}" href="#/lecture/${x.id}">${inner}</a>`;
      })}</div></aside>
  </div>`.s;
  document.title = `${l.title} | المؤرخ`;
  const btn = $('#done', root);
  btn.onclick = async () => {
    btn.disabled = true;
    try {
      const r = await post(`/lectures/${l.id}/progress`, { completed: !l.completed });
      l.completed = r.completed;
      btn.className = 'btn ' + (l.completed ? 'btn-ok' : 'btn-ghost');
      btn.textContent = l.completed ? '✓ تمت المشاهدة' : 'علّم كمشاهدة';
      if (l.completed) toast('تم حفظ تقدمك');
    } catch (e) { fail(e); }
    btn.disabled = false;
  };
}

/* ============================ الاختبار ============================ */
let timer = null;
window.addEventListener('hashchange', () => { clearInterval(timer); timer = null; });
const LETTERS = ['أ', 'ب', 'ج', 'د', 'هـ', 'و'];
const mmss = (s) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;

export async function quiz(root, { params }) {
  clearInterval(timer);
  root.innerHTML = spinner().s;
  const d = await get(`/quizzes/${params.id}`);
  const q = d.quiz;
  const best = d.attempts.reduce((m, a) => Math.max(m, a.total ? Math.round((a.score / a.total) * 100) : 0), 0);
  root.innerHTML = html`<div class="card quiz-box stack">
    <div class="crumbs muted small"><a href="#/course/${d.course.id}">${d.course.title}</a></div>
    <h1 style="font-family:var(--display)">${q.title}</h1>
    <div class="row"><span class="badge">${num(q.questions_count)} سؤال</span><span class="badge">${num(q.duration_min)} دقيقة</span><span class="badge">النجاح من ${num(q.pass_percent)}%</span></div>
    <p class="muted">الوقت بيبدأ أول ما تضغط ابدأ، ولو قفلت الصفحة هيكمل العد. اختار إجابة واحدة لكل سؤال.</p>
    ${d.attempts.length ? html`<div><b>محاولاتك السابقة</b> <span class="muted small">(أعلى نتيجة ${num(best)}%)</span>
      <div style="margin-top:8px">${d.attempts.slice(0, 5).map((a) => html`<div class="row small" style="justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--line)"><span>${fmtDateTime(a.submitted_at)}</span><b>${num(a.score)} / ${num(a.total)}</b></div>`)}</div></div>` : ''}
    <button class="btn btn-lg" id="start" ${raw(q.questions_count ? '' : 'disabled')}>${d.attempts.length ? 'ابدأ محاولة جديدة' : 'ابدأ الاختبار'}</button>
  </div>`.s;
  $('#start', root).onclick = async (e) => {
    e.target.disabled = true;
    try { runQuiz(root, d, await post(`/quizzes/${params.id}/start`)); } catch (er) { fail(er); e.target.disabled = false; }
  };
}

function runQuiz(root, meta, att) {
  const qs = att.questions;
  const answers = {};
  let idx = 0, left = att.remaining_seconds, submitting = false;

  const draw = () => {
    const cur = qs[idx];
    const answered = Object.keys(answers).length;
    root.innerHTML = html`<div class="card quiz-box">
      <div class="q-top"><span class="muted">سؤال ${num(idx + 1)} من ${num(qs.length)}</span><span class="timer${left < 60 ? ' low' : ''}" id="tm" role="timer">${mmss(left)}</span></div>
      <div class="progress"><i style="width:${(answered / qs.length) * 100}%"></i></div>
      <p class="q-text">${cur.text}</p>
      <div role="radiogroup">${cur.options.map((o, i) => html`<button class="opt${answers[cur.id] === i ? ' sel' : ''}" role="radio" aria-checked="${answers[cur.id] === i}" data-i="${i}"><span class="k">${LETTERS[i]}</span><span>${o}</span></button>`)}</div>
      <div class="row" style="justify-content:space-between;margin-top:14px">
        <button class="btn btn-ghost" id="prev" ${raw(idx === 0 ? 'disabled' : '')}>السابق</button>
        ${idx < qs.length - 1 ? html`<button class="btn" id="next">التالي</button>` : html`<button class="btn btn-gold" id="finish">تسليم الاختبار</button>`}
      </div>
      <div class="dots">${qs.map((x, i) => html`<button class="dot${answers[x.id] !== undefined ? ' ans' : ''}${i === idx ? ' cur' : ''}" data-go="${i}" aria-label="سؤال ${i + 1}">${num(i + 1)}</button>`)}</div>
    </div>`.s;
  };
  draw();

  const submit = async (auto) => {
    if (submitting) return; submitting = true; clearInterval(timer);
    try {
      const r = await post(`/attempts/${att.attempt_id}/submit`, { answers });
      showResult(root, meta, r, auto);
    } catch (e) { fail(e); submitting = false; }
  };
  bind(root, 'click', '.opt', (e, t) => { answers[qs[idx].id] = Number(t.dataset.i); draw(); });
  bind(root, 'click', '#prev', () => { idx--; draw(); });
  bind(root, 'click', '#next', () => { idx++; draw(); });
  bind(root, 'click', '[data-go]', (e, t) => { idx = Number(t.dataset.go); draw(); });
  bind(root, 'click', '#finish', async () => {
    const missing = qs.length - Object.keys(answers).length;
    if (missing > 0 && !confirm(`لسه ${missing} سؤال من غير إجابة. تسلّم برضه؟`)) return;
    submit(false);
  });
  timer = setInterval(() => {
    left--;
    const tm = $('#tm', root);
    if (tm) { tm.textContent = mmss(Math.max(left, 0)); tm.classList.toggle('low', left < 60); }
    if (left <= 0) submit(true);
  }, 1000);
}

function showResult(root, meta, r, auto) {
  root.innerHTML = html`<div class="card quiz-box">
    <div class="center stack">
      ${auto ? html`<p class="muted">انتهى الوقت وتم تسليم إجاباتك تلقائيًا.</p>` : ''}
      <div class="score" style="color:${r.passed ? 'var(--ok)' : 'var(--bad)'}">${num(r.percent)}%</div>
      <p><b>${num(r.score)}</b> من <b>${num(r.total)}</b> إجابة صحيحة. ${r.passed ? 'مبروك، نجحت في الاختبار!' : `النجاح من ${num(r.pass_percent)}%، راجع الأخطاء وحاول تاني.`}</p>
      <div class="row" style="justify-content:center"><a class="btn" href="#/quiz/${meta.quiz.id}">محاولة جديدة</a><a class="btn btn-ghost" href="#/course/${meta.course.id}">رجوع للكورس</a></div>
    </div>
    <h2 style="font-family:var(--display);margin:28px 0 14px">مراجعة الإجابات</h2>
    ${r.review.map((q, n) => html`<div style="margin-bottom:22px">
      <p class="q-text" style="font-size:1.1rem;margin:0 0 10px">${num(n + 1)}. ${q.text}</p>
      ${q.options.map((o, i) => html`<div class="opt ${i === q.correct_index ? 'good' : i === q.picked ? 'wrong' : ''}" style="cursor:default"><span class="k">${LETTERS[i]}</span><span>${o}</span>${i === q.correct_index ? html`<b class="small" style="margin-inline-start:auto">الإجابة الصحيحة</b>` : i === q.picked ? html`<b class="small" style="margin-inline-start:auto">إجابتك</b>` : ''}</div>`)}
      ${q.picked === null ? html`<p class="small" style="color:var(--bad)">لم تجب عن السؤال ده.</p>` : ''}
      ${q.explanation ? html`<div class="explain"><b>التوضيح:</b> ${q.explanation}</div>` : ''}
    </div>`)}
  </div>`.s;
  window.scrollTo({ top: 0 });
}
