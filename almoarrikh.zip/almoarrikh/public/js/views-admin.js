import { html, raw, bind, $, $$, num, fmtDate, fmtDateTime, fmtMin, spinner, emptyBox, toast, formModal, confirmBox, esc } from './ui.js';
import { state, get, post, put, del, navigate, fail } from './core.js';

const NAV = [
  ['', 'لوحة التحكم'], ['courses', 'الكورسات والمحاضرات'], ['codes', 'أكواد الاشتراك'],
  ['students', 'الطلاب'], ['announcements', 'الإعلانات'], ['settings', 'إعدادات المنصة']
];

export async function admin(root, { params, query }) {
  const sec = params.section || '';
  const activeNav = ['course', 'quiz'].includes(sec) ? 'courses' : sec === 'student' ? 'students' : sec;
  root.innerHTML = html`<div class="admin">
    <nav class="a-side" aria-label="لوحة التحكم">${NAV.map(([k, t]) => html`<a href="#/admin${k ? '/' + k : ''}" class="${activeNav === k ? 'on' : ''}">${t}</a>`)}</nav>
    <div class="a-main" id="box">${spinner()}</div></div>`.s;
  const box = $('#box', root);
  const views = { '': dash, courses, course, quiz, codes, students, student, announcements, settings };
  const fn = views[sec];
  if (!fn) { box.innerHTML = emptyBox('الصفحة غير موجودة', '').s; return; }
  try { await fn(box, params, query); } catch (e) { box.innerHTML = html`<div class="err">${e.message}</div>`.s; }
}

const pager = (page, pages) => pages > 1 ? html`<div class="pager"><button class="btn btn-ghost btn-sm" data-pg="${page - 1}" ${raw(page <= 1 ? 'disabled' : '')}>السابق</button><span class="muted small">${num(page)} / ${num(pages)}</span><button class="btn btn-ghost btn-sm" data-pg="${page + 1}" ${raw(page >= pages ? 'disabled' : '')}>التالي</button></div>` : '';
const yn = (v, a, b) => (v ? html`<span class="badge ok">${a}</span>` : html`<span class="badge">${b}</span>`);
const gOpts = (grades) => grades.map((g) => ({ value: g.id, label: g.name }));

/* ============================ لوحة التحكم ============================ */
async function dash(box) {
  const s = await get('/admin/stats');
  const max = Math.max(1, ...s.by_grade.map((g) => g.n));
  box.innerHTML = html`<h1>لوحة التحكم</h1>
  <div class="stats">
    <div class="card stat"><b>${num(s.students)}</b><span>طالب مسجل</span></div>
    <div class="card stat"><b>${num(s.students_today)}</b><span>تسجيل النهاردة</span></div>
    <div class="card stat"><b>${num(s.enrollments)}</b><span>اشتراك في الكورسات</span></div>
    <div class="card stat"><b>${num(s.courses)}</b><span>كورس</span></div>
    <div class="card stat"><b>${num(s.lectures)}</b><span>محاضرة</span></div>
    <div class="card stat"><b>${num(s.codes_used)} / ${num(s.codes_total)}</b><span>أكواد مستخدمة</span></div>
    <div class="card stat"><b>${num(s.attempts)}</b><span>محاولة اختبار</span></div>
  </div>
  <div class="grid c2">
    <div class="card" style="padding:20px"><h3 style="margin-bottom:8px">الطلاب حسب الصف</h3>${s.by_grade.map((g) => html`<div class="bar"><span class="lbl">${g.short}</span><span class="tr"><i style="width:${(g.n / max) * 100}%"></i></span><b>${num(g.n)}</b></div>`)}
      <h3 style="margin:22px 0 6px">الكورسات الأكثر اشتراكًا</h3>${s.top_courses.length ? s.top_courses.map((c) => html`<div class="row small" style="justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--line)"><a href="#/admin/course/${c.id}">${c.title}</a><b>${num(c.n)}</b></div>`) : html`<p class="muted small">لسه مفيش كورسات.</p>`}</div>
    <div class="card" style="padding:20px"><h3 style="margin-bottom:8px">آخر المسجلين</h3>${s.recent_students.length ? s.recent_students.map((u) => html`<a class="row small" href="#/admin/student/${u.id}" style="justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--line)"><span>${u.name}</span><span class="muted">${fmtDate(u.created_at)}</span></a>`) : html`<p class="muted small">مفيش طلاب لسه.</p>`}</div>
  </div>`.s;
}

/* ============================ الكورسات ============================ */
const courseFields = (c, grades) => [
  { name: 'title', label: 'اسم الكورس', required: true, value: c?.title },
  { name: 'grade', label: 'الصف الدراسي', type: 'select', options: gOpts(grades), value: c?.grade },
  { name: 'price', label: 'السعر (جنيه)', type: 'number', value: c?.price ?? 0, hint: 'اكتب 0 لو الكورس مجاني' },
  { name: 'description', label: 'وصف الكورس', type: 'textarea', value: c?.description },
  { name: 'cover_url', label: 'رابط صورة الغلاف (اختياري)', type: 'url', ltr: true, value: c?.cover_url, hint: 'لو فاضي بيظهر غلاف تلقائي بلون الصف' },
  { name: 'is_published', label: 'منشور للطلاب', type: 'checkbox', value: c ? !!c.is_published : false }
];

async function courses(box) {
  const d = await get('/admin/courses');
  const gname = Object.fromEntries(d.grades.map((g) => [g.id, g.short]));
  box.innerHTML = html`<div class="row" style="justify-content:space-between"><h1>الكورسات والمحاضرات</h1><button class="btn" id="new">+ كورس جديد</button></div>
  ${d.courses.length ? html`<div class="tbl-wrap"><table><thead><tr><th>الكورس</th><th>الصف</th><th>السعر</th><th>محاضرات</th><th>مشتركين</th><th>الحالة</th><th></th></tr></thead><tbody>
    ${d.courses.map((c) => html`<tr><td class="wrap-t"><a href="#/admin/course/${c.id}"><b>${c.title}</b></a></td><td>${gname[c.grade]}</td><td>${c.price ? num(c.price) + ' ج.م' : 'مجاني'}</td><td>${num(c.lectures_count)}</td><td>${num(c.students_count)}</td><td>${yn(c.is_published, 'منشور', 'مسودة')}</td>
    <td><a class="btn btn-sm" href="#/admin/course/${c.id}">إدارة</a></td></tr>`)}</tbody></table></div>`
  : html`<div class="card">${emptyBox('مفيش كورسات لسه', 'ابدأ بإنشاء أول كورس ثم أضف المحاضرات.')}</div>`}`.s;
  $('#new', box).onclick = () => formModal({ title: 'كورس جديد', fields: courseFields(null, d.grades), submit: async (v) => {
    const r = await post('/admin/courses', v); toast('تم إنشاء الكورس'); navigate('/admin/course/' + r.id);
  } });
}

const lectureFields = (l) => [
  { name: 'title', label: 'عنوان المحاضرة', required: true, value: l?.title },
  { name: 'video_url', label: 'رابط الفيديو', type: 'url', ltr: true, value: l?.video_url, hint: 'يوتيوب (يفضل Unlisted) أو Vimeo أو Bunny Stream أو Google Drive أو رابط mp4 مباشر. لازم https.' },
  { name: 'pdf_url', label: 'رابط المذكرة PDF (اختياري)', type: 'url', ltr: true, value: l?.pdf_url },
  { name: 'duration_min', label: 'مدة المحاضرة بالدقائق', type: 'number', value: l?.duration_min ?? 0 },
  { name: 'description', label: 'وصف / ملاحظات', type: 'textarea', value: l?.description },
  { name: 'is_free', label: 'محاضرة مجانية (تظهر لأي طالب مسجل)', type: 'checkbox', value: !!l?.is_free },
  { name: 'is_published', label: 'منشورة', type: 'checkbox', value: l ? !!l.is_published : true }
];

async function course(box, { id }) {
  const [d, all] = await Promise.all([get(`/admin/courses/${id}`), get('/admin/courses')]);
  const c = d.course;
  const reload = () => course(box, { id });
  box.innerHTML = html`<div class="crumbs muted small"><a href="#/admin/courses">الكورسات</a></div>
  <div class="row" style="justify-content:space-between;margin-bottom:20px"><h1 style="margin:0">${c.title}</h1>
    <div class="row">${yn(c.is_published, 'منشور', 'مسودة')}<a class="btn btn-ghost btn-sm" href="#/course/${c.id}">معاينة</a><button class="btn btn-ghost btn-sm" id="edit">تعديل</button><button class="btn btn-danger btn-sm" id="rm">حذف</button></div></div>
  <div class="card" style="margin-bottom:22px"><div class="row" style="padding:14px 18px;border-bottom:1px solid var(--line);justify-content:space-between"><b>المحاضرات (${num(d.lectures.length)})</b><button class="btn btn-sm" id="addl">+ محاضرة</button></div>
    ${d.lectures.length ? d.lectures.map((l, i) => html`<div class="lec"><span class="no">${num(i + 1)}</span><span class="t"><b>${l.title}</b><span class="muted small">${[fmtMin(l.duration_min), l.video_url ? 'فيديو' : 'بدون فيديو', l.pdf_url ? 'مذكرة' : ''].filter(Boolean).join('، ')}</span></span>
      ${l.is_free ? html`<span class="badge ok">مجانية</span>` : ''}${l.is_published ? '' : html`<span class="badge">مخفية</span>`}
      <span class="row" style="gap:4px"><button class="btn btn-ghost btn-sm" data-mv="up" data-id="${l.id}" aria-label="لأعلى" ${raw(i === 0 ? 'disabled' : '')}>▲</button><button class="btn btn-ghost btn-sm" data-mv="down" data-id="${l.id}" aria-label="لأسفل" ${raw(i === d.lectures.length - 1 ? 'disabled' : '')}>▼</button>
      <button class="btn btn-ghost btn-sm" data-el="${l.id}">تعديل</button><button class="btn btn-ghost btn-sm" data-dl="${l.id}">حذف</button></span></div>`)
    : emptyBox('مفيش محاضرات', 'أضف أول محاضرة بالضغط على "+ محاضرة".')}</div>
  <div class="card"><div class="row" style="padding:14px 18px;border-bottom:1px solid var(--line);justify-content:space-between"><b>الاختبارات (${num(d.quizzes.length)})</b><a class="btn btn-sm" href="#/admin/quiz/new?course=${c.id}">+ اختبار</a></div>
    ${d.quizzes.length ? d.quizzes.map((q) => html`<div class="lec"><span class="t"><b>${q.title}</b><span class="muted small">${num(q.questions_count)} سؤال، ${num(q.duration_min)} دقيقة</span></span>${yn(q.is_published, 'منشور', 'مسودة')}
      <a class="btn btn-ghost btn-sm" href="#/admin/quiz/${q.id}">تعديل</a><button class="btn btn-ghost btn-sm" data-dq="${q.id}">حذف</button></div>`) : emptyBox('مفيش اختبارات', 'الاختبارات بتظهر للطلاب المشتركين بس.')}</div>`.s;

  $('#edit', box).onclick = () => formModal({ title: 'تعديل الكورس', fields: courseFields(c, all.grades), submit: async (v) => { await put(`/admin/courses/${c.id}`, v); toast('تم الحفظ'); reload(); } });
  $('#rm', box).onclick = async () => {
    if (await confirmBox(`هيتم حذف الكورس "${c.title}" بكل محاضراته واختباراته وأكواده واشتراكات الطلاب. مينفعش التراجع.`, { ok: 'احذف الكورس', danger: true })) {
      try { await del(`/admin/courses/${c.id}`); toast('تم الحذف'); navigate('/admin/courses'); } catch (e) { fail(e); }
    }
  };
  $('#addl', box).onclick = () => formModal({ title: 'محاضرة جديدة', fields: lectureFields(null), submit: async (v) => { await post(`/admin/courses/${c.id}/lectures`, v); toast('تمت إضافة المحاضرة'); reload(); } });
  bind(box, 'click', '[data-el]', (e, t) => {
    const l = d.lectures.find((x) => x.id === Number(t.dataset.el));
    formModal({ title: 'تعديل المحاضرة', fields: lectureFields(l), submit: async (v) => { await put(`/admin/lectures/${l.id}`, v); toast('تم الحفظ'); reload(); } });
  });
  bind(box, 'click', '[data-dl]', async (e, t) => {
    if (await confirmBox('تحذف المحاضرة دي؟', { ok: 'حذف', danger: true })) { try { await del(`/admin/lectures/${t.dataset.dl}`); reload(); } catch (er) { fail(er); } }
  });
  bind(box, 'click', '[data-mv]', async (e, t) => { try { await post(`/admin/lectures/${t.dataset.id}/move`, { dir: t.dataset.mv }); reload(); } catch (er) { fail(er); } });
  bind(box, 'click', '[data-dq]', async (e, t) => {
    if (await confirmBox('تحذف الاختبار ده ونتايج الطلاب فيه؟', { ok: 'حذف', danger: true })) { try { await del(`/admin/quizzes/${t.dataset.dq}`); reload(); } catch (er) { fail(er); } }
  });
}

/* ============================ محرر الاختبار ============================ */
const LET = ['أ', 'ب', 'ج', 'د', 'هـ', 'و'];
function parseBulk(text) {
  const out = [];
  for (const block of text.replace(/\r/g, '').split(/\n\s*\n/)) {
    const lines = block.split('\n').map((l) => l.trim()).filter(Boolean);
    if (!lines.length) continue;
    const q = { text: '', options: [], correct_index: 0, explanation: '' };
    let ans = null;
    for (const ln of lines) {
      let m;
      if ((m = ln.match(/^(?:الإجابة|الاجابة|الجواب|Answer)\s*[:：]\s*(.+)$/i))) ans = m[1].trim();
      else if ((m = ln.match(/^(?:توضيح|شرح|التوضيح)\s*[:：]\s*(.+)$/))) q.explanation = m[1];
      else if ((m = ln.match(/^(?:[أابجدهو]ـ?|[A-Fa-f]|[1-6])\s*[\)\-\.]\s*(.+)$/)) && q.text) q.options.push(m[1]);
      else if (!q.text) q.text = ln.replace(/^(?:س|سؤال|\d+)\s*[:：\.\)\-]\s*/, '');
      else q.text += ' ' + ln;
    }
    if (ans) {
      const a = ans.charAt(0);
      let i = ['أ', 'ا', 'ب', 'ج', 'د', 'ه', 'هـ', 'و'].indexOf(ans) ;
      if (i < 0) i = ['أ', 'ب', 'ج', 'د', 'ه', 'و'].indexOf(a === 'ا' ? 'أ' : a);
      if (i < 0 && /^[A-Fa-f]$/.test(a)) i = a.toLowerCase().charCodeAt(0) - 97;
      if (i < 0 && /^[1-6]$/.test(a)) i = Number(a) - 1;
      if (i >= 0 && i < q.options.length) q.correct_index = i;
    }
    if (q.text && q.options.length >= 2) out.push(q);
  }
  return out;
}

async function quiz(box, { id }, query) {
  const isNew = id === 'new';
  let m, lectures = [], courseId;
  if (isNew) {
    courseId = Number(query.course);
    const cd = await get(`/admin/courses/${courseId}`);
    lectures = cd.lectures;
    m = { title: '', duration_min: 15, pass_percent: 50, lecture_id: '', is_published: false, questions: [{ text: '', options: ['', '', '', ''], correct_index: 0, explanation: '' }] };
  } else {
    const d = await get(`/admin/quizzes/${id}`);
    courseId = d.quiz.course_id; lectures = d.lectures;
    m = { ...d.quiz, lecture_id: d.quiz.lecture_id || '', questions: d.questions.map((q) => ({ text: q.text, options: [...q.options], correct_index: q.correct_index, explanation: q.explanation })) };
  }
  const qHtml = () => m.questions.map((q, i) => html`<div class="card q-edit" data-q="${i}">
    <div class="row" style="justify-content:space-between;margin-bottom:8px"><b>سؤال ${num(i + 1)}</b><button class="btn btn-ghost btn-sm" data-rmq="${i}">حذف السؤال</button></div>
    <div class="field"><textarea class="textarea" style="min-height:70px" data-f="text" placeholder="نص السؤال" aria-label="نص السؤال">${q.text}</textarea></div>
    <p class="small muted" style="margin-bottom:6px">اختار الدائرة بجانب الإجابة الصحيحة:</p>
    ${q.options.map((o, k) => html`<div class="opt-edit"><input type="radio" name="c${i}" data-correct="${k}" ${raw(q.correct_index === k ? 'checked' : '')} aria-label="الإجابة الصحيحة ${LET[k]}"><input class="input" data-o="${k}" value="${o}" placeholder="الاختيار ${LET[k]}" aria-label="الاختيار ${LET[k]}">${q.options.length > 2 ? html`<button class="btn btn-ghost btn-sm" data-rmo="${k}" aria-label="حذف الاختيار">✕</button>` : ''}</div>`)}
    ${q.options.length < 6 ? html`<button class="btn btn-ghost btn-sm" data-addo>+ اختيار</button>` : ''}
    <div class="field" style="margin:12px 0 0"><input class="input" data-f="explanation" value="${q.explanation}" placeholder="توضيح الإجابة (اختياري، بيظهر بعد التسليم)" aria-label="توضيح الإجابة"></div></div>`);
  box.innerHTML = html`<div class="crumbs muted small"><a href="#/admin/course/${courseId}">رجوع للكورس</a></div>
  <h1>${isNew ? 'اختبار جديد' : 'تعديل الاختبار'}</h1>
  <div class="card" style="padding:20px;margin-bottom:20px"><div id="qerr"></div>
    <div class="field"><label for="qt">عنوان الاختبار</label><input class="input" id="qt" value="${m.title}"></div>
    <div class="two"><div class="field"><label for="qd">المدة بالدقائق</label><input class="input" id="qd" type="number" min="1" value="${m.duration_min}"></div>
    <div class="field"><label for="qp">نسبة النجاح %</label><input class="input" id="qp" type="number" min="1" max="100" value="${m.pass_percent}"></div></div>
    <div class="field"><label for="ql">مرتبط بمحاضرة (اختياري)</label><select class="select" id="ql"><option value="">كل الكورس</option>${lectures.map((l) => html`<option value="${l.id}" ${raw(String(m.lecture_id) === String(l.id) ? 'selected' : '')}>${l.title}</option>`)}</select></div>
    <label class="check"><input type="checkbox" id="qpub" ${raw(m.is_published ? 'checked' : '')}> منشور للطلاب</label></div>
  <div class="row" style="justify-content:space-between;margin-bottom:12px"><h2 style="font-family:var(--display)">الأسئلة (<span id="qc">${num(m.questions.length)}</span>)</h2><button class="btn btn-ghost btn-sm" id="bulk">لصق أسئلة دفعة واحدة</button></div>
  <div id="qs">${qHtml()}</div>
  <div class="row"><button class="btn btn-ghost" id="addq">+ سؤال جديد</button><span class="grow"></span><button class="btn btn-lg" id="save">حفظ الاختبار</button></div>`.s;

  const redraw = () => { $('#qs', box).innerHTML = qHtml().s; $('#qc', box).textContent = num(m.questions.length); };
  const qi = (t) => Number(t.closest('[data-q]').dataset.q);
  box.addEventListener('input', (e) => {
    const t = e.target; if (!t.closest('[data-q]')) return;
    const q = m.questions[qi(t)];
    if (t.dataset.f) q[t.dataset.f] = t.value;
    else if (t.dataset.o !== undefined) q.options[Number(t.dataset.o)] = t.value;
  });
  box.addEventListener('change', (e) => { const t = e.target; if (t.dataset.correct !== undefined) m.questions[qi(t)].correct_index = Number(t.dataset.correct); });
  bind(box, 'click', '[data-rmq]', (e, t) => { m.questions.splice(Number(t.dataset.rmq), 1); redraw(); });
  bind(box, 'click', '[data-addo]', (e, t) => { m.questions[qi(t)].options.push(''); redraw(); });
  bind(box, 'click', '[data-rmo]', (e, t) => {
    const q = m.questions[qi(t)]; const k = Number(t.dataset.rmo);
    q.options.splice(k, 1); if (q.correct_index >= q.options.length) q.correct_index = 0; else if (q.correct_index > k) q.correct_index--;
    redraw();
  });
  $('#addq', box).onclick = () => { m.questions.push({ text: '', options: ['', '', '', ''], correct_index: 0, explanation: '' }); redraw(); $$('[data-q]', box).at(-1)?.scrollIntoView({ block: 'center' }); };
  $('#bulk', box).onclick = () => formModal({
    title: 'لصق أسئلة', wide: true, submitText: 'إضافة الأسئلة',
    fields: [{ name: 'text', type: 'textarea', label: 'الصق الأسئلة هنا', required: true, placeholder: 'س: من قاد الحملة الفرنسية على مصر؟\nأ) محمد علي\nب) نابليون بونابرت\nج) كليبر\nد) عرابي\nالإجابة: ب\nتوضيح: قادها نابليون سنة 1798', hint: 'افصل بين كل سؤال والتاني بسطر فاضي. الإجابة بحرف الاختيار (أ ب ج د).' }],
    submit: async (v) => {
      const parsed = parseBulk(v.text);
      if (!parsed.length) throw new Error('مقدرتش أقرأ أسئلة، تأكد من الشكل الموضح في المثال');
      if (m.questions.length === 1 && !m.questions[0].text) m.questions = [];
      m.questions.push(...parsed); redraw(); toast(`تمت إضافة ${num(parsed.length)} سؤال`);
    }
  });
  $('#save', box).onclick = async (e) => {
    e.target.disabled = true;
    const body = {
      title: $('#qt', box).value, duration_min: $('#qd', box).value, pass_percent: $('#qp', box).value,
      lecture_id: $('#ql', box).value || null, is_published: $('#qpub', box).checked, questions: m.questions
    };
    try {
      if (isNew) { const r = await post(`/admin/courses/${courseId}/quizzes`, body); toast('تم حفظ الاختبار'); navigate('/admin/quiz/' + r.id); }
      else { await put(`/admin/quizzes/${id}`, body); toast('تم حفظ الاختبار'); }
    } catch (er) { $('#qerr', box).innerHTML = html`<div class="err">${er.message}</div>`.s; window.scrollTo({ top: 0, behavior: 'smooth' }); }
    e.target.disabled = false;
  };
}

/* ============================ الأكواد ============================ */
async function codes(box, _p, query) {
  const f = { course_id: query.course_id || '', status: query.status || '', page: Number(query.page) || 1 };
  const [cs, list] = await Promise.all([get('/admin/courses'), get(`/admin/codes?course_id=${f.course_id}&status=${f.status}&page=${f.page}`)]);
  box.innerHTML = html`<h1>أكواد الاشتراك</h1>
  <div class="card" style="padding:20px;margin-bottom:22px"><h3 style="margin-bottom:12px">توليد أكواد جديدة</h3>
    <form id="gen" class="row" style="align-items:flex-end"><div class="field" style="margin:0;min-width:240px"><label for="gc">الكورس</label><select class="select" id="gc" required><option value="">اختار الكورس</option>${cs.courses.map((c) => html`<option value="${c.id}">${c.title}</option>`)}</select></div>
      <div class="field" style="margin:0;width:120px"><label for="gn">العدد</label><input class="input" id="gn" type="number" min="1" max="500" value="10"></div><button class="btn" type="submit">توليد</button></form>
    <div id="gout"></div></div>
  <div class="row" style="margin-bottom:14px"><select class="select" id="fc" style="width:auto" aria-label="الكورس"><option value="">كل الكورسات</option>${cs.courses.map((c) => html`<option value="${c.id}" ${raw(String(c.id) === String(f.course_id) ? 'selected' : '')}>${c.title}</option>`)}</select>
    <select class="select" id="fs" style="width:auto" aria-label="الحالة"><option value="">كل الحالات</option><option value="unused" ${raw(f.status === 'unused' ? 'selected' : '')}>غير مستخدمة</option><option value="used" ${raw(f.status === 'used' ? 'selected' : '')}>مستخدمة</option></select>
    <span class="grow"></span><a class="btn btn-ghost btn-sm" href="/api/admin/codes.csv?course_id=${f.course_id}&status=${f.status}">تحميل CSV</a></div>
  ${list.codes.length ? html`<div class="tbl-wrap"><table><thead><tr><th>الكود</th><th>الكورس</th><th>الحالة</th><th>استخدمه</th><th>تاريخ</th><th></th></tr></thead><tbody>
    ${list.codes.map((c) => html`<tr><td><span class="mono">${c.code}</span></td><td class="wrap-t">${c.course_title}</td><td>${yn(c.used_at, 'مستخدم', 'متاح')}</td><td>${c.used_by_name ? html`${c.used_by_name} <span class="muted small">${c.used_by_phone}</span>` : '-'}</td><td>${fmtDate(c.used_at || c.created_at)}</td><td>${c.used_at ? '' : html`<button class="btn btn-ghost btn-sm" data-dc="${c.id}">حذف</button>`}</td></tr>`)}</tbody></table></div>${pager(list.page, list.pages)}`
    : html`<div class="card">${emptyBox('مفيش أكواد', 'ولّد أكواد لكورس من النموذج فوق.')}</div>`}
  <p class="muted small" style="margin-top:10px">إجمالي ${num(list.total)} كود.</p>`.s;
  const go = (o) => { const q = { ...f, ...o }; navigate(`/admin/codes?course_id=${q.course_id}&status=${q.status}&page=${q.page}`); };
  $('#fc', box).onchange = (e) => go({ course_id: e.target.value, page: 1 });
  $('#fs', box).onchange = (e) => go({ status: e.target.value, page: 1 });
  bind(box, 'click', '[data-pg]', (e, t) => go({ page: Number(t.dataset.pg) }));
  bind(box, 'click', '[data-dc]', async (e, t) => { try { await del(`/admin/codes/${t.dataset.dc}`); codes(box, _p, query); } catch (er) { fail(er); } });
  $('#gen', box).onsubmit = async (e) => {
    e.preventDefault();
    try {
      const r = await post('/admin/codes', { course_id: $('#gc', box).value, count: $('#gn', box).value });
      const text = r.codes.join('\n');
      $('#gout', box).innerHTML = html`<div style="margin-top:16px"><div class="row" style="margin-bottom:8px"><b>تم توليد ${num(r.codes.length)} كود</b><button class="btn btn-gold btn-sm" id="cp">نسخ الكل</button><span class="muted small">اطبعهم أو انسخهم الآن، وهتلاقيهم دايمًا في الجدول تحت.</span></div><div class="codes-out" tabindex="0">${text}</div></div>`.s;
      $('#cp', box).onclick = async () => { try { await navigator.clipboard.writeText(text); toast('تم النسخ'); } catch { toast('انسخ الأكواد يدويًا من المربع', 'bad'); } };
    } catch (er) { fail(er); }
  };
}

/* ============================ الطلاب ============================ */
async function students(box, _p, query) {
  const f = { q: query.q || '', grade: query.grade || '', page: Number(query.page) || 1 };
  const d = await get(`/admin/students?q=${encodeURIComponent(f.q)}&grade=${f.grade}&page=${f.page}`);
  const gname = Object.fromEntries(d.grades.map((g) => [g.id, g.short]));
  box.innerHTML = html`<div class="row" style="justify-content:space-between"><h1>الطلاب (${num(d.total)})</h1><a class="btn btn-ghost btn-sm" href="/api/admin/students.csv">تحميل CSV</a></div>
  <form id="sf" class="row" style="margin-bottom:14px"><input class="input" id="sq" style="max-width:300px" placeholder="ابحث بالاسم أو الموبايل" value="${f.q}" aria-label="بحث">
    <select class="select" id="sg" style="width:auto" aria-label="الصف"><option value="">كل الصفوف</option>${d.grades.map((g) => html`<option value="${g.id}" ${raw(g.id === f.grade ? 'selected' : '')}>${g.name}</option>`)}</select><button class="btn" type="submit">بحث</button></form>
  ${d.students.length ? html`<div class="tbl-wrap"><table><thead><tr><th>الاسم</th><th>الموبايل</th><th>ولي الأمر</th><th>الصف</th><th>كورسات</th><th>آخر دخول</th><th></th></tr></thead><tbody>
    ${d.students.map((s) => html`<tr><td><a href="#/admin/student/${s.id}"><b>${s.name}</b></a> ${s.is_banned ? html`<span class="badge bad">موقوف</span>` : ''}</td><td><span class="mono">${s.phone}</span></td><td><span class="mono">${s.parent_phone}</span></td><td>${gname[s.grade] || '-'}</td><td>${num(s.courses_count)}</td><td>${fmtDate(s.last_login)}</td><td><a class="btn btn-ghost btn-sm" href="#/admin/student/${s.id}">التفاصيل</a></td></tr>`)}</tbody></table></div>${pager(d.page, d.pages)}`
    : html`<div class="card">${emptyBox('مفيش طلاب مطابقين', 'جرّب بحث تاني.')}</div>`}`.s;
  const go = (o) => { const q = { ...f, ...o }; navigate(`/admin/students?q=${encodeURIComponent(q.q)}&grade=${q.grade}&page=${q.page}`); };
  $('#sf', box).onsubmit = (e) => { e.preventDefault(); go({ q: $('#sq', box).value.trim(), grade: $('#sg', box).value, page: 1 }); };
  bind(box, 'click', '[data-pg]', (e, t) => go({ page: Number(t.dataset.pg) }));
}

async function student(box, { id }) {
  const d = await get(`/admin/students/${id}`);
  const s = d.student;
  const reload = () => student(box, { id });
  const enrolledIds = new Set(d.enrollments.map((e) => e.course_id));
  const free = d.courses.filter((c) => !enrolledIds.has(c.id));
  box.innerHTML = html`<div class="crumbs muted small"><a href="#/admin/students">الطلاب</a></div>
  <div class="row" style="justify-content:space-between;margin-bottom:18px"><h1 style="margin:0">${s.name} ${s.is_banned ? html`<span class="badge bad">موقوف</span>` : ''}</h1>
    <div class="row"><button class="btn btn-ghost btn-sm" id="pw">تغيير كلمة المرور</button><button class="btn btn-ghost btn-sm" id="lo">إخراج من كل الأجهزة (${num(d.devices)})</button><button class="btn ${s.is_banned ? 'btn-ok' : 'btn-danger'} btn-sm" id="ban">${s.is_banned ? 'إلغاء الإيقاف' : 'إيقاف الحساب'}</button></div></div>
  <div class="grid c2">
    <div class="card" style="padding:20px"><h3 style="margin-bottom:8px">البيانات</h3>
      <p>الموبايل: <span class="mono">${s.phone}</span></p><p>ولي الأمر: <span class="mono">${s.parent_phone}</span></p><p>التسجيل: ${fmtDate(s.created_at)}</p><p>آخر دخول: ${fmtDateTime(s.last_login)}</p></div>
    <div class="card" style="padding:20px"><h3 style="margin-bottom:8px">إضافة اشتراك يدوي</h3>
      ${free.length ? html`<form id="en" class="row"><select class="select" id="ec" style="flex:1;min-width:180px">${free.map((c) => html`<option value="${c.id}">${c.title}</option>`)}</select><button class="btn" type="submit">اشترك</button></form>` : html`<p class="muted">الطالب مشترك في كل الكورسات.</p>`}</div>
  </div>
  <div class="card" style="margin-top:20px"><div style="padding:14px 18px;border-bottom:1px solid var(--line)"><b>الاشتراكات</b></div>
    ${d.enrollments.length ? d.enrollments.map((e) => html`<div class="lec"><span class="t"><b>${e.title}</b><span class="muted small">${e.source === 'code' ? 'بكود' : 'يدوي'} - ${fmtDate(e.created_at)} - تقدم ${num(e.progress.percent)}%</span></span><button class="btn btn-ghost btn-sm" data-ue="${e.id}">إلغاء الاشتراك</button></div>`) : emptyBox('مفيش اشتراكات', '')}</div>
  <div class="card" style="margin-top:20px"><div style="padding:14px 18px;border-bottom:1px solid var(--line)"><b>نتائج الاختبارات</b></div>
    ${d.attempts.length ? d.attempts.map((a) => html`<div class="lec"><span class="t"><b>${a.title}</b><span class="muted small">${fmtDateTime(a.submitted_at)}</span></span><span class="badge">${num(a.score)} / ${num(a.total)}</span></div>`) : emptyBox('مفيش اختبارات', '')}</div>`.s;

  $('#ban', box).onclick = async () => { try { await put(`/admin/students/${id}`, { is_banned: !s.is_banned }); toast('تم'); reload(); } catch (e) { fail(e); } };
  $('#lo', box).onclick = async () => { try { await post(`/admin/students/${id}/logout-devices`); toast('تم إخراج الطالب من كل الأجهزة'); reload(); } catch (e) { fail(e); } };
  $('#pw', box).onclick = () => formModal({ title: 'كلمة مرور جديدة للطالب', fields: [{ name: 'password', label: 'كلمة المرور الجديدة', required: true, hint: '6 أحرف على الأقل. هيتخرج الطالب من كل أجهزته.' }], submit: async (v) => { await post(`/admin/students/${id}/reset-password`, v); toast('تم تغيير كلمة المرور'); reload(); } });
  const en = $('#en', box);
  if (en) en.onsubmit = async (e) => { e.preventDefault(); try { await post(`/admin/students/${id}/enroll`, { course_id: $('#ec', box).value }); toast('تم الاشتراك'); reload(); } catch (er) { fail(er); } };
  bind(box, 'click', '[data-ue]', async (e, t) => { if (await confirmBox('تلغي اشتراك الطالب في الكورس ده؟', { ok: 'إلغاء الاشتراك', danger: true })) { try { await del(`/admin/enrollments/${t.dataset.ue}`); reload(); } catch (er) { fail(er); } } });
}

/* ============================ الإعلانات ============================ */
async function announcements(box) {
  const d = await get('/admin/announcements');
  const reload = () => announcements(box);
  const gname = Object.fromEntries(d.grades.map((g) => [g.id, g.short]));
  const fields = (a) => [
    { name: 'title', label: 'العنوان', required: true, value: a?.title },
    { name: 'body', label: 'التفاصيل', type: 'textarea', value: a?.body },
    { name: 'grade', label: 'يظهر لـ', type: 'select', options: [{ value: '', label: 'كل الصفوف' }, ...gOpts(d.grades)], value: a?.grade || '' },
    { name: 'is_active', label: 'ظاهر الآن', type: 'checkbox', value: a ? !!a.is_active : true }
  ];
  box.innerHTML = html`<div class="row" style="justify-content:space-between"><h1>الإعلانات</h1><button class="btn" id="new">+ إعلان جديد</button></div>
  <p class="muted small" style="margin:-8px 0 16px">الإعلانات بتظهر في الصفحة الرئيسية وفي لوحة الطالب.</p>
  ${d.announcements.length ? html`<div class="card">${d.announcements.map((a) => html`<div class="lec"><span class="t"><b>${a.title}</b><span class="muted small">${a.grade ? gname[a.grade] : 'كل الصفوف'} - ${fmtDate(a.created_at)}</span></span>${yn(a.is_active, 'ظاهر', 'مخفي')}<button class="btn btn-ghost btn-sm" data-e="${a.id}">تعديل</button><button class="btn btn-ghost btn-sm" data-d="${a.id}">حذف</button></div>`)}</div>` : html`<div class="card">${emptyBox('مفيش إعلانات', 'أضف إعلان لتنبيه الطلاب بموعد أو كورس جديد.')}</div>`}`.s;
  $('#new', box).onclick = () => formModal({ title: 'إعلان جديد', fields: fields(null), submit: async (v) => { await post('/admin/announcements', v); toast('تم النشر'); reload(); } });
  bind(box, 'click', '[data-e]', (e, t) => { const a = d.announcements.find((x) => x.id === Number(t.dataset.e)); formModal({ title: 'تعديل الإعلان', fields: fields(a), submit: async (v) => { await put(`/admin/announcements/${a.id}`, v); toast('تم الحفظ'); reload(); } }); });
  bind(box, 'click', '[data-d]', async (e, t) => { if (await confirmBox('تحذف الإعلان؟', { ok: 'حذف', danger: true })) { try { await del(`/admin/announcements/${t.dataset.d}`); reload(); } catch (er) { fail(er); } } });
}

/* ============================ الإعدادات ============================ */
async function settings(box) {
  const { settings: s } = await get('/admin/settings');
  const F = (name, label, o = {}) => html`<div class="field"><label for="s_${name}">${label}</label>${o.area ? html`<textarea class="textarea" id="s_${name}" name="${name}">${s[name]}</textarea>` : html`<input class="input" id="s_${name}" name="${name}" value="${s[name]}" ${raw(o.ltr ? 'dir="ltr" style="text-align:right"' : '')}>`}${o.hint ? html`<span class="hint">${o.hint}</span>` : ''}</div>`;
  box.innerHTML = html`<h1>إعدادات المنصة</h1><form id="sf" class="card" style="padding:22px;max-width:680px" novalidate><div id="serr"></div>
    <div class="two">${F('teacher_name', 'اسم المدرس')}${F('teacher_nick', 'اللقب (اسم المنصة)')}</div>
    ${F('tagline', 'الشعار تحت العنوان')}${F('teacher_bio', 'نبذة عن المدرس', { area: true })}
    ${F('teacher_photo', 'رابط صورة المدرس', { ltr: true, hint: 'رابط https لصورة مربعة. لو فاضي بيظهر أول حرف من الاسم.' })}
    <div class="two">${F('whatsapp', 'واتساب للتواصل وطلب الأكواد', { ltr: true, hint: 'مثال: 01012345678' })}${F('support_phone', 'رقم الدعم', { ltr: true })}</div>
    ${F('youtube', 'رابط قناة يوتيوب', { ltr: true })}${F('facebook', 'رابط فيسبوك', { ltr: true })}${F('telegram', 'رابط تيليجرام', { ltr: true })}
    <button class="btn btn-lg" type="submit">حفظ الإعدادات</button></form>`.s;
  const f = $('#sf', box);
  f.onsubmit = async (e) => {
    e.preventDefault();
    const body = Object.fromEntries([...new FormData(f).entries()]);
    try { await put('/admin/settings', body); state.settings = null; toast('تم حفظ الإعدادات'); $('#serr', box).innerHTML = ''; }
    catch (er) { $('#serr', box).innerHTML = html`<div class="err">${er.message}</div>`.s; }
  };
}
