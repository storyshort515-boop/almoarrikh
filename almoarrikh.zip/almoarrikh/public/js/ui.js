/* أدوات الواجهة: قوالب آمنة ضد XSS، نوافذ، نماذج، تنسيقات */
export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
class Raw { constructor(s) { this.s = s; } toString() { return this.s; } }
export const raw = (s) => new Raw(s);
const render = (v) => (v == null || v === false ? '' : v instanceof Raw ? v.s : Array.isArray(v) ? v.map(render).join('') : esc(v));
/** قالب HTML: كل القيم بتتعمل لها escape تلقائيًا إلا لو لُفّت بـ raw() أو html`` */
export const html = (st, ...v) => new Raw(st.reduce((a, s, i) => a + s + (i < v.length ? render(v[i]) : ''), ''));

export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export function bind(root, type, sel, fn) {
  root.addEventListener(type, (e) => { const t = e.target.closest(sel); if (t && root.contains(t)) fn(e, t); });
}
export function node(h) { const d = document.createElement('div'); d.innerHTML = h.s ?? h; return d; }

/* ---------- تنسيقات ---------- */
const AR_DIGITS = (s) => String(s).replace(/\d/g, (d) => '٠١٢٣٤٥٦٧٨٩'[d]);
export const num = (n) => AR_DIGITS(Number(n || 0).toLocaleString('en-US'));
export const fmtDate = (ts) => (ts ? new Date(ts * 1000).toLocaleDateString('ar-EG', { year: 'numeric', month: 'short', day: 'numeric' }) : '-');
export const fmtDateTime = (ts) => (ts ? new Date(ts * 1000).toLocaleString('ar-EG', { dateStyle: 'medium', timeStyle: 'short' }) : '-');
export function fmtMin(m) {
  m = Number(m || 0);
  if (!m) return '';
  if (m < 60) return `${num(m)} دقيقة`;
  const h = Math.floor(m / 60), r = m % 60;
  return r ? `${num(h)} ساعة و${num(r)} دقيقة` : `${num(h)} ساعة`;
}
export const price = (p) => (p > 0 ? html`${num(p)} <small>ج.م</small>` : html`مجاني`);
export function waLink(phone, text) {
  const p = String(phone || '').replace(/\D/g, '');
  if (!p) return '';
  const intl = p.startsWith('0') ? '2' + p : p;
  return `https://wa.me/${intl}?text=${encodeURIComponent(text || '')}`;
}
export const safeUrl = (u) => (/^https?:\/\//i.test(u || '') ? u : '');

/* ---------- toast ---------- */
export function toast(msg, kind = 'ok') {
  const t = document.createElement('div');
  t.className = 'toast' + (kind === 'bad' ? ' bad' : '');
  t.textContent = msg;
  $('#toasts').append(t);
  setTimeout(() => t.remove(), 3800);
}

/* ---------- modal ---------- */
export function modal(content, { wide = false } = {}) {
  const back = document.createElement('div');
  back.className = 'backdrop';
  back.innerHTML = `<div class="modal${wide ? ' wide' : ''}" role="dialog" aria-modal="true">${content.s ?? content}</div>`;
  const prevFocus = document.activeElement;
  const close = () => { back.remove(); document.removeEventListener('keydown', onKey); prevFocus?.focus?.(); };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', onKey);
  back.addEventListener('mousedown', (e) => { if (e.target === back) close(); });
  document.body.append(back);
  back.querySelector('input,select,textarea,button')?.focus();
  return { el: back.firstElementChild, close };
}

export function confirmBox(message, { ok = 'تأكيد', danger = false } = {}) {
  return new Promise((resolve) => {
    const m = modal(html`<h2>تأكيد</h2><p style="margin-bottom:18px">${message}</p>
      <div class="acts"><button class="btn ${danger ? 'btn-danger' : ''}" data-y>${ok}</button><button class="btn btn-ghost" data-n>إلغاء</button></div>`);
    const done = (v) => { m.close(); resolve(v); };
    m.el.querySelector('[data-y]').onclick = () => done(true);
    m.el.querySelector('[data-n]').onclick = () => done(false);
  });
}

/** نموذج منبثق: fields = [{name,label,type,options,hint,required,value,placeholder,ltr}] */
export function formModal({ title, fields, submitText = 'حفظ', submit, wide = false }) {
  return new Promise((resolve) => {
    const fh = fields.map((f) => {
      const id = 'f_' + f.name;
      const common = `id="${id}" name="${esc(f.name)}"${f.required ? ' required' : ''}${f.placeholder ? ` placeholder="${esc(f.placeholder)}"` : ''}${f.ltr ? ' dir="ltr" style="text-align:right"' : ''}`;
      let ctl;
      if (f.type === 'checkbox') return html`<div class="field"><label class="check"><input type="checkbox" ${raw(`id="${id}" name="${esc(f.name)}"${f.value ? ' checked' : ''}`)}> ${f.label}</label>${f.hint ? html`<span class="hint">${f.hint}</span>` : ''}</div>`;
      if (f.type === 'textarea') ctl = html`<textarea class="textarea" ${raw(common)}>${f.value ?? ''}</textarea>`;
      else if (f.type === 'select') ctl = html`<select class="select" ${raw(common)}>${(f.options || []).map((o) => html`<option value="${o.value}" ${raw(String(o.value) === String(f.value ?? '') ? 'selected' : '')}>${o.label}</option>`)}</select>`;
      else ctl = html`<input class="input" type="${f.type || 'text'}" ${raw(common)} value="${f.value ?? ''}" ${raw(f.type === 'number' ? 'inputmode="numeric"' : '')}>`;
      return html`<div class="field"><label for="${id}">${f.label}</label>${ctl}${f.hint ? html`<span class="hint">${f.hint}</span>` : ''}</div>`;
    });
    const m = modal(html`<h2>${title}</h2><form novalidate><div data-err></div>${fh}<div class="acts"><button class="btn" type="submit">${submitText}</button><button class="btn btn-ghost" type="button" data-cancel>إلغاء</button></div></form>`, { wide });
    const form = m.el.querySelector('form');
    m.el.querySelector('[data-cancel]').onclick = () => { m.close(); resolve(false); };
    form.onsubmit = async (e) => {
      e.preventDefault();
      const vals = {};
      for (const f of fields) {
        const el = form.elements[f.name];
        vals[f.name] = f.type === 'checkbox' ? el.checked : el.value;
      }
      const btn = form.querySelector('[type=submit]');
      btn.disabled = true;
      try { await submit(vals); m.close(); resolve(true); }
      catch (err) { form.querySelector('[data-err]').innerHTML = `<div class="err">${esc(err.message)}</div>`; btn.disabled = false; }
    };
  });
}

export const spinner = () => html`<div class="loading"><div class="spin" role="status" aria-label="جاري التحميل"></div></div>`;
export const emptyBox = (title, text, action) => html`<div class="empty-box"><h3>${title}</h3><p>${text}</p>${action || ''}</div>`;
export const gradeBadge = (grades, id) => grades?.find((g) => g.id === id)?.short || '';
