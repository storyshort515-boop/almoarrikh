import { html, $, bind, spinner, esc, safeUrl, waLink } from './ui.js';
import { state, get, refreshUser, logout, isAdmin } from './core.js';
import * as pub from './views-public.js';
import * as stu from './views-student.js';
import { admin } from './views-admin.js';

const ROUTES = [
  ['/', pub.home], ['/login', pub.login, { guest: true }], ['/register', pub.register, { guest: true }],
  ['/courses', pub.courses], ['/course/:id', pub.course],
  ['/me', stu.me, { auth: true }], ['/lecture/:id', stu.lecture, { auth: true }], ['/quiz/:id', stu.quiz, { auth: true }],
  ['/admin', admin, { admin: true }], ['/admin/:section', admin, { admin: true }], ['/admin/:section/:id', admin, { admin: true }]
].map(([p, fn, opt]) => {
  const keys = [];
  const re = new RegExp('^' + p.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
  return { re, keys, fn, opt: opt || {} };
});

function parseHash() {
  const raw = location.hash.slice(1) || '/';
  const [path, qs] = raw.split('?');
  return { path: path.replace(/\/+$/, '') || '/', query: Object.fromEntries(new URLSearchParams(qs || '')) };
}

let seq = 0;
async function route() {
  const my = ++seq;
  const { path, query } = parseHash();
  const app = $('#app');
  document.title = 'المؤرخ | منصة الأستاذ سعيد إسماعيل لتاريخ الثانوي العام';
  for (const r of ROUTES) {
    const m = r.re.exec(path);
    if (!m) continue;
    const params = {};
    r.keys.forEach((k, i) => (params[k] = decodeURIComponent(m[i + 1])));
    if ((r.opt.auth || r.opt.admin) && !state.user) { location.hash = '#/login?next=' + encodeURIComponent(location.hash.slice(1)); return; }
    if (r.opt.admin && !isAdmin()) { location.hash = '#/'; return; }
    const page = document.createElement('div');
    page.innerHTML = spinner().s;
    app.replaceChildren(page);
    window.scrollTo({ top: 0 });
    try { await r.fn(page, { params, query }); }
    catch (e) {
      if (my !== seq) return;
      page.innerHTML = html`<div class="wrap"><div class="card" style="max-width:520px;margin:60px auto;padding:30px;text-align:center"><h2>${e.status === 404 ? 'الصفحة مش موجودة' : 'حصل خطأ'}</h2><p class="muted" style="margin:8px 0 16px">${e.message}</p><a class="btn" href="#/">الرئيسية</a></div></div>`.s;
    }
    if (my === seq) { renderFooter(); app.focus({ preventScroll: true }); }
    return;
  }
  app.innerHTML = html`<div class="wrap"><div class="card" style="max-width:520px;margin:60px auto;padding:30px;text-align:center"><h2>الصفحة مش موجودة</h2><a class="btn" style="margin-top:14px" href="#/">الرئيسية</a></div></div>`.s;
}

function renderHeader() {
  const u = state.user;
  const { path } = parseHash();
  const on = (p) => (path === p || (p !== '/' && path.startsWith(p)) ? 'on' : '');
  $('#header').className = 'hdr';
  $('#header').innerHTML = html`<div class="wrap">
    <a class="logo" href="#/">${pub.logoSvg}<span>المؤرخ</span></a>
    <nav class="nav" id="nav" aria-label="القائمة الرئيسية">
      <a href="#/" class="${on('/') && path === '/' ? 'on' : ''}">الرئيسية</a>
      <a href="#/courses" class="${on('/courses')}">الكورسات</a>
      ${u ? html`<a href="#/me" class="${on('/me')}">كورساتي</a>` : ''}
      ${u?.role === 'admin' ? html`<a href="#/admin" class="${on('/admin')}">لوحة التحكم</a>` : ''}
    </nav>
    <span class="sp"></span>
    ${u ? html`<button class="btn btn-light btn-sm hide-m" id="logout">تسجيل الخروج</button>`
        : html`<a class="btn btn-light btn-sm" href="#/login">دخول</a><a class="btn btn-gold btn-sm hide-m" href="#/register">حساب جديد</a>`}
    <button class="burger" id="burger" aria-label="القائمة" aria-expanded="false">☰</button>
  </div>`.s;
  $('#burger').onclick = (e) => { const o = $('#nav').classList.toggle('open'); e.currentTarget.setAttribute('aria-expanded', o); };
  $('#nav').onclick = () => $('#nav').classList.remove('open');
  $('#logout')?.addEventListener('click', logout);
}

async function renderFooter() {
  const f = $('#footer');
  if (parseHash().path.startsWith('/admin')) { f.innerHTML = ''; f.className = ''; return; }
  if (!state.settings) { try { state.settings = (await get('/home')).settings; } catch { state.settings = {}; } }
  const s = state.settings;
  f.className = 'ftr';
  f.innerHTML = html`<div class="wrap">
    <div><div class="logo">${pub.logoSvg}<span>المؤرخ</span></div><p class="small" style="margin-top:8px">منصة الأستاذ ${s.teacher_name || ''} لتاريخ الثانوي العام</p></div>
    <div class="links">
      <a href="#/courses">الكورسات</a>
      ${s.whatsapp ? html`<a href="${waLink(s.whatsapp, '')}" target="_blank" rel="noopener">واتساب</a>` : ''}
      ${safeUrl(s.youtube) ? html`<a href="${s.youtube}" target="_blank" rel="noopener">يوتيوب</a>` : ''}
      ${safeUrl(s.facebook) ? html`<a href="${s.facebook}" target="_blank" rel="noopener">فيسبوك</a>` : ''}
      ${safeUrl(s.telegram) ? html`<a href="${s.telegram}" target="_blank" rel="noopener">تيليجرام</a>` : ''}
    </div>
    <p class="small" style="width:100%;border-top:1px solid rgba(255,255,255,.1);padding-top:16px">جميع الحقوق محفوظة، المؤرخ ${new Date().getFullYear()}</p>
  </div>`.s;
}

let ready = false;
window.addEventListener('auth-changed', () => { renderHeader(); if (ready && parseHash().path === '/') route(); });
window.addEventListener('hashchange', () => { renderHeader(); route(); });

await refreshUser();
ready = true;
renderHeader();
route();
