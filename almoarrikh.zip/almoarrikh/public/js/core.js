import { toast } from './ui.js';

export const state = { user: null, settings: null };

export async function api(path, { method = 'GET', body } = {}) {
  let res;
  try {
    res = await fetch('/api' + path, {
      method, credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
      body: body !== undefined ? JSON.stringify(body) : undefined
    });
  } catch {
    throw Object.assign(new Error('مفيش اتصال بالإنترنت، تأكد من الشبكة وحاول تاني'), { status: 0 });
  }
  let data = null;
  try { data = await res.json(); } catch { /* not json */ }
  if (!res.ok) {
    const err = new Error(data?.error || 'حصل خطأ، حاول تاني');
    err.status = res.status;
    if (res.status === 401 && state.user) { state.user = null; window.dispatchEvent(new Event('auth-changed')); }
    throw err;
  }
  return data;
}
export const get = (p) => api(p);
export const post = (p, body = {}) => api(p, { method: 'POST', body });
export const put = (p, body = {}) => api(p, { method: 'PUT', body });
export const del = (p) => api(p, { method: 'DELETE' });

export function navigate(path) { location.hash = '#' + path; }
export const isAdmin = () => state.user?.role === 'admin';

export async function refreshUser() {
  try { state.user = (await get('/auth/me')).user; } catch { state.user = null; }
  window.dispatchEvent(new Event('auth-changed'));
}
export async function logout() {
  try { await post('/auth/logout'); } catch { /* ignore */ }
  state.user = null;
  window.dispatchEvent(new Event('auth-changed'));
  navigate('/');
  toast('تم تسجيل الخروج');
}
export function fail(e) { toast(e.message || 'حصل خطأ', 'bad'); }
